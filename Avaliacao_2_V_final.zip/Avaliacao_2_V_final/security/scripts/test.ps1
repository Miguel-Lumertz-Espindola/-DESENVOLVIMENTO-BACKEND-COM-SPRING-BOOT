param([string]$PgBin = 'C:\Program Files\PostgreSQL\17\bin', [string]$MavenCommand = '')
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$targetRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot 'target'))
$testRoot = [IO.Path]::GetFullPath((Join-Path $targetRoot ('postgres-test-' + [Guid]::NewGuid().ToString('N'))))
if (-not $testRoot.StartsWith($targetRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'O diretório de testes está fora de target.'
}
foreach ($binary in @('initdb.exe','pg_ctl.exe','createdb.exe')) {
    if (-not (Test-Path -LiteralPath (Join-Path $PgBin $binary))) { throw "Executável não encontrado: $binary em $PgBin" }
}
$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, 0)
$listener.Start(); $testPort = $listener.LocalEndpoint.Port; $listener.Stop()
$previousUrl = $env:TEST_DB_URL; $previousUser = $env:TEST_DB_USERNAME; $previousPassword = $env:TEST_DB_PASSWORD
$started = $false
New-Item -ItemType Directory -Path $testRoot -Force | Out-Null
Push-Location $projectRoot
try {
    & (Join-Path $PgBin 'initdb.exe') -D $testRoot -U security_test -A trust --encoding=UTF8 --locale=C
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao inicializar PostgreSQL de testes.' }
    & (Join-Path $PgBin 'pg_ctl.exe') -D $testRoot -l (Join-Path $testRoot 'server.log') -o "-h 127.0.0.1 -p $testPort" -w start
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao iniciar PostgreSQL de testes.' }
    $started = $true
    & (Join-Path $PgBin 'createdb.exe') -h 127.0.0.1 -p $testPort -U security_test security_tests
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar banco isolado.' }
    $env:TEST_DB_URL = "jdbc:postgresql://127.0.0.1:$testPort/security_tests"
    $env:TEST_DB_USERNAME = 'security_test'; $env:TEST_DB_PASSWORD = ''
    if ([string]::IsNullOrEmpty($MavenCommand)) { $MavenCommand = Join-Path $projectRoot 'mvnw.cmd' }
    & $MavenCommand test
    if ($LASTEXITCODE -ne 0) { throw 'Os testes falharam. Consulte target/surefire-reports.' }
} finally {
    if ($started) { & (Join-Path $PgBin 'pg_ctl.exe') -D $testRoot -m fast -w stop }
    $env:TEST_DB_URL = $previousUrl; $env:TEST_DB_USERNAME = $previousUser; $env:TEST_DB_PASSWORD = $previousPassword
    Pop-Location
}
