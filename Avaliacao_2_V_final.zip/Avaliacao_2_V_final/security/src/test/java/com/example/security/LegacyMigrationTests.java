package com.example.security;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import javax.sql.DataSource;
import java.util.UUID;
import static org.assertj.core.api.Assertions.*;

@SpringBootTest @ActiveProfiles("test")
class LegacyMigrationTests {
    @Autowired DataSource dataSource;
    @Autowired JdbcTemplate jdbc;
    @Test void atualizacaoPreservaContasERegistrosLegados() {
        assertThat(jdbc.queryForObject("select current_database()",String.class)).endsWith("_tests");
        String schema="migration_"+UUID.randomUUID().toString().replace("-", "");
        try {
            Flyway.configure().dataSource(dataSource).schemas(schema).defaultSchema(schema)
                    .target("10").load().migrate();
            jdbc.update("insert into "+schema+".users(name,email,password) values ('Existente','EXISTENTE@TESTE.COM','hash-preservado')");
            jdbc.update("insert into "+schema+".jogador(nome,email,senha) values ('Antigo','antigo@teste.com','legado')");
            jdbc.update("insert into "+schema+".item(nome,descrição,tipo,valor) values ('Antigo',123,'ESPADA',10)");
            Flyway.configure().dataSource(dataSource).schemas(schema).defaultSchema(schema).load().migrate();
            assertThat(jdbc.queryForObject("select password from "+schema+".users",String.class)).isEqualTo("hash-preservado");
            assertThat(jdbc.queryForObject("select role from "+schema+".users",String.class)).isEqualTo("JOGADOR");
            assertThat(jdbc.queryForObject("select nome from "+schema+".jogador_legado",String.class)).isEqualTo("Antigo");
            assertThat(jdbc.queryForObject("select nome from "+schema+".item_legado",String.class)).isEqualTo("Antigo");
            assertThat(jdbc.queryForObject("select count(*) from "+schema+".jogadores",Long.class)).isZero();
        } finally {
            jdbc.execute("drop schema if exists "+schema+" cascade");
        }
    }
}
