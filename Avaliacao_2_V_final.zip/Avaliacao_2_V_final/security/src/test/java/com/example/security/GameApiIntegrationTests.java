package com.example.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.example.security.config.TokenConfig;
import com.example.security.entity.*;
import com.example.security.repository.UserRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpMethod;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.*;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.JsonNode;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest @AutoConfigureMockMvc @ActiveProfiles("test")
class GameApiIntegrationTests {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired JdbcTemplate jdbc;
    @Autowired UserRepository users;
    @Autowired PasswordEncoder encoder;
    @Autowired TokenConfig tokens;
    String admin, jogador, outro;

    @BeforeEach void preparar() {
        // Protege contra configuração acidental de um banco de desenvolvimento real.
        assertThat(jdbc.queryForObject("select current_database()", String.class)).endsWith("_tests");
        jdbc.execute("TRUNCATE jogadores_conquistas, personagens_missoes, itens_inventario, inventarios, personagens, jogadores, conquistas, missoes, itens, users RESTART IDENTITY CASCADE");
        admin = conta("admin@teste.com", Role.ADMIN);
        jogador = conta("jogador@teste.com", Role.JOGADOR);
        outro = conta("outro@teste.com", Role.JOGADOR);
    }
    String conta(String email, Role role) {
        var u = new User(); u.setName(email); u.setEmail(email); u.setRole(role);
        u.setPassword(encoder.encode("Senha123!")); return tokens.generateToken(users.saveAndFlush(u));
    }
    ResultActions chamada(String method, String path, String token, Object body) throws Exception {
        MockHttpServletRequestBuilder r = request(HttpMethod.valueOf(method), path);
        if (token != null) r.header("Authorization", "Bearer " + token);
        if (body != null) r.contentType("application/json").content(json.writeValueAsString(body));
        return mvc.perform(r);
    }
    JsonNode resposta(ResultActions r, int status) throws Exception {
        return json.readTree(r.andExpect(status().is(status)).andReturn().getResponse().getContentAsString());
    }
    long criar(String path, String token, Object data) throws Exception {
        return resposta(chamada("POST", path, token, data), 201).path("id").asLong();
    }
    long jogador(String token) throws Exception { return criar("/jogadores", token, Map.of("nome", "Aventureiro")); }
    long personagem(String token) throws Exception {
        jogador(token); return criar("/personagens", token, Map.of("nome", "Artemis", "classe", "Mago"));
    }
    Map<String,Object> dados(String recurso, String nome) {
        return switch (recurso) {
            case "itens" -> Map.of("nome", nome, "descricao", "Item de teste", "tipo", "ARMA", "valor", 25.50);
            case "missoes" -> Map.of("nome", nome, "descricao", "Missão de teste", "recompensaXp", 150);
            case "conquistas" -> Map.of("nome", nome, "descricao", "Conquista de teste");
            default -> throw new IllegalArgumentException(recurso);
        };
    }

    @Test void cadastroLoginValidacaoEEmailUnico() throws Exception {
        chamada("POST", "/auth/register", null, Map.of("name","Novo","email","novo@teste.com","password","Senha123!","role","ADMIN"))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.password").doesNotExist());
        assertThat(users.findByEmailIgnoreCase("novo@teste.com").orElseThrow().getRole()).isEqualTo(Role.JOGADOR);
        assertThat(encoder.matches("Senha123!", users.findByEmailIgnoreCase("novo@teste.com").orElseThrow().getPassword())).isTrue();
        chamada("POST", "/auth/register", null, Map.of("name","Novo","email","NOVO@teste.com","password","Senha123!"))
                .andExpect(status().isConflict());
        chamada("POST", "/auth/register", null, Map.of("name"," ","email","invalido","password","123"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.fieldErrors.email").exists());
        chamada("POST", "/auth/login", null, Map.of("email","novo@teste.com","password","errada"))
                .andExpect(status().isUnauthorized());
        var login = resposta(chamada("POST", "/auth/login", null, Map.of("email","NOVO@teste.com","password","Senha123!")),200);
        chamada("GET", "/auth/me", login.path("token").asString(), null).andExpect(status().isOk())
                .andExpect(jsonPath("$.role").value("JOGADOR")).andExpect(jsonPath("$.password").doesNotExist());
    }

    @Test void acessoSemTokenInvalidoExpiradoOuContaRemovida() throws Exception {
        chamada("GET", "/itens", null, null).andExpect(status().isUnauthorized());
        chamada("GET", "/itens", "invalido", null).andExpect(status().isUnauthorized());
        String expirado = JWT.create().withIssuer("guilda-quest").withClaim("userId",2L)
                .withExpiresAt(Instant.now().minusSeconds(5))
                .sign(Algorithm.HMAC256("chave-exclusiva-dos-testes-com-mais-de-32-bytes"));
        chamada("GET", "/itens", expirado, null).andExpect(status().isUnauthorized());
        users.delete(users.findByEmailIgnoreCase("outro@teste.com").orElseThrow());
        chamada("GET", "/itens", outro, null).andExpect(status().isUnauthorized());
    }

    @Test void crudCompletoDeJogadorEPersonagem() throws Exception {
        long j = jogador(jogador);
        chamada("POST", "/jogadores", jogador, Map.of("nome","Segundo")).andExpect(status().isConflict());
        chamada("GET", "/jogadores/"+j, jogador, null).andExpect(status().isOk());
        chamada("GET", "/jogadores", jogador, null).andExpect(status().isOk()).andExpect(jsonPath("$.totalElementos").value(1));
        chamada("PUT", "/jogadores/"+j, jogador, Map.of("nome","Novo nome")).andExpect(status().isOk())
                .andExpect(jsonPath("$.nome").value("Novo nome"));
        long p = criar("/personagens", jogador, Map.of("nome","Herói","classe","Mago","nivel",999,"experiencia",99999));
        chamada("GET", "/personagens/"+p, jogador, null).andExpect(status().isOk())
                .andExpect(jsonPath("$.nivel").value(1)).andExpect(jsonPath("$.experiencia").value(0));
        chamada("GET", "/personagens", jogador, null).andExpect(status().isOk()).andExpect(jsonPath("$.totalElementos").value(1));
        chamada("PUT", "/personagens/"+p, jogador, Map.of("nome","Renomeado","classe","Guerreiro"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.nome").value("Renomeado"));
        chamada("DELETE", "/personagens/"+p, jogador, null).andExpect(status().isNoContent());
        chamada("GET", "/personagens/"+p, jogador, null).andExpect(status().isNotFound());
        chamada("DELETE", "/jogadores/"+j, jogador, null).andExpect(status().isNoContent());
        chamada("GET", "/jogadores/"+j, jogador, null).andExpect(status().isNotFound());
    }

    @ParameterizedTest @ValueSource(strings = {"itens","missoes","conquistas"})
    void crudCompletoDosCatalogos(String recurso) throws Exception {
        String base = "/"+recurso;
        long id = criar(base, admin, dados(recurso,"Original"));
        chamada("GET", base+"/"+id, jogador, null).andExpect(status().isOk()).andExpect(jsonPath("$.nome").value("Original"));
        chamada("GET", base+"?size=500", jogador, null).andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElementos").value(1)).andExpect(jsonPath("$.tamanho").value(100));
        chamada("PUT", base+"/"+id, admin, dados(recurso,"Alterado")).andExpect(status().isOk())
                .andExpect(jsonPath("$.nome").value("Alterado"));
        chamada("DELETE", base+"/"+id, admin, null).andExpect(status().isNoContent());
        chamada("GET", base+"/"+id, admin, null).andExpect(status().isNotFound());
    }

    @ParameterizedTest @ValueSource(strings = {"itens","missoes","conquistas"})
    void jogadorNaoPodeModificarCatalogos(String recurso) throws Exception {
        var data=dados(recurso,"Teste"); long id=criar("/"+recurso,admin,data);
        chamada("POST", "/"+recurso, jogador, data).andExpect(status().isForbidden());
        chamada("PUT", "/"+recurso+"/"+id, jogador, data).andExpect(status().isForbidden());
        chamada("DELETE", "/"+recurso+"/"+id, jogador, null).andExpect(status().isForbidden());
    }

    @Test void usuarioSoAcessaSeusPropriosDados() throws Exception {
        long p=personagem(jogador); long j=jdbc.queryForObject("select jogador_id from personagens where id=?",Long.class,p);
        personagem(outro);
        long item=criar("/itens",admin,dados("itens","Espada"));
        long missao=criar("/missoes",admin,dados("missoes","Missão"));
        for (String path : List.of("/jogadores/"+j, "/personagens/"+p, "/personagens/"+p+"/inventario",
                "/personagens/"+p+"/missoes", "/jogadores/"+j+"/conquistas"))
            chamada("GET",path,outro,null).andExpect(status().isForbidden());
        chamada("PUT","/jogadores/"+j,outro,Map.of("nome","Roubo")).andExpect(status().isForbidden());
        chamada("DELETE","/jogadores/"+j,outro,null).andExpect(status().isForbidden());
        chamada("PUT","/personagens/"+p,outro,Map.of("nome","Roubo","classe","Mago")).andExpect(status().isForbidden());
        chamada("DELETE","/personagens/"+p,outro,null).andExpect(status().isForbidden());
        chamada("POST","/personagens/"+p+"/inventario/itens",outro,Map.of("itemId",item,"quantidade",1)).andExpect(status().isForbidden());
        chamada("PUT","/personagens/"+p+"/inventario",outro,Map.of("capacidade",30)).andExpect(status().isForbidden());
        chamada("PUT","/personagens/"+p+"/inventario/itens/"+item,outro,Map.of("quantidade",2)).andExpect(status().isForbidden());
        chamada("DELETE","/personagens/"+p+"/inventario/itens/"+item,outro,null).andExpect(status().isForbidden());
        chamada("POST","/personagens/"+p+"/missoes/"+missao,outro,null).andExpect(status().isForbidden());
        chamada("PATCH","/personagens/"+p+"/missoes/"+missao+"/concluir",outro,null).andExpect(status().isForbidden());
        chamada("GET","/personagens",outro,null).andExpect(status().isOk()).andExpect(jsonPath("$.totalElementos").value(1));
        chamada("GET","/personagens",admin,null).andExpect(status().isOk()).andExpect(jsonPath("$.totalElementos").value(2));
    }

    @Test void inventarioRespeitaCapacidadeQuantidadesEVinculos() throws Exception {
        long p=personagem(jogador), item=criar("/itens",admin,dados("itens","Espada")), item2=criar("/itens",admin,dados("itens","Poção"));
        String base="/personagens/"+p+"/inventario";
        chamada("GET",base,jogador,null).andExpect(status().isOk()).andExpect(jsonPath("$.capacidade").value(20));
        chamada("PUT",base,jogador,Map.of("capacidade",1)).andExpect(status().isOk());
        chamada("POST",base+"/itens",jogador,Map.of("itemId",item,"quantidade",1)).andExpect(status().isOk());
        chamada("POST",base+"/itens",jogador,Map.of("itemId",item,"quantidade",2)).andExpect(status().isOk())
                .andExpect(jsonPath("$.itens[0].quantidade").value(3));
        chamada("POST",base+"/itens",jogador,Map.of("itemId",item2,"quantidade",1)).andExpect(status().isConflict());
        chamada("POST",base+"/itens",jogador,Map.of("itemId",item2,"quantidade",0)).andExpect(status().isBadRequest());
        chamada("DELETE","/itens/"+item,admin,null).andExpect(status().isConflict());
        chamada("PUT",base+"/itens/"+item,jogador,Map.of("quantidade",1000000)).andExpect(status().isOk());
        chamada("POST",base+"/itens",jogador,Map.of("itemId",item,"quantidade",1)).andExpect(status().isConflict());
        chamada("PUT",base,jogador,Map.of("capacidade",2)).andExpect(status().isOk());
        chamada("POST",base+"/itens",jogador,Map.of("itemId",item2,"quantidade",1)).andExpect(status().isOk());
        chamada("PUT",base,jogador,Map.of("capacidade",1)).andExpect(status().isConflict());
        chamada("DELETE",base+"/itens/"+item,jogador,null).andExpect(status().isNoContent());
        chamada("DELETE","/itens/"+item,admin,null).andExpect(status().isNoContent());
    }

    @Test void missaoEntregaRecompensaFixadaUmaUnicaVez() throws Exception {
        long p=personagem(jogador), m=criar("/missoes",admin,dados("missoes","Primeira"));
        String base="/personagens/"+p+"/missoes/"+m;
        chamada("PATCH",base+"/concluir",jogador,null).andExpect(status().isNotFound());
        chamada("POST",base,jogador,null).andExpect(status().isCreated()).andExpect(jsonPath("$.dataConclusao").isEmpty());
        chamada("POST",base,jogador,null).andExpect(status().isConflict());
        chamada("PUT","/missoes/"+m,admin,Map.of("nome","Alterada","descricao","Nova","recompensaXp",900)).andExpect(status().isOk());
        chamada("PATCH",base+"/concluir",jogador,null).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("CONCLUIDA"));
        chamada("PATCH",base+"/concluir",jogador,null).andExpect(status().isConflict());
        chamada("GET","/personagens/"+p,jogador,null).andExpect(status().isOk())
                .andExpect(jsonPath("$.experiencia").value(150)).andExpect(jsonPath("$.nivel").value(2));
        chamada("DELETE","/missoes/"+m,admin,null).andExpect(status().isConflict());
    }

    @Test void duasConclusoesConcorrentesNaoDuplicamExperiencia() throws Exception {
        long p=personagem(jogador), m=criar("/missoes",admin,dados("missoes","Concorrente"));
        String base="/personagens/"+p+"/missoes/"+m;
        chamada("POST",base,jogador,null).andExpect(status().isCreated());
        var ready=new CountDownLatch(2); var start=new CountDownLatch(1);
        try (var pool=Executors.newFixedThreadPool(2)) {
            Callable<Integer> concluir=() -> {
                ready.countDown(); if (!start.await(10,TimeUnit.SECONDS)) throw new IllegalStateException("Timeout");
                return chamada("PATCH",base+"/concluir",jogador,null).andReturn().getResponse().getStatus();
            };
            var a=pool.submit(concluir); var b=pool.submit(concluir);
            assertThat(ready.await(10,TimeUnit.SECONDS)).isTrue(); start.countDown();
            assertThat(List.of(a.get(20,TimeUnit.SECONDS),b.get(20,TimeUnit.SECONDS))).containsExactlyInAnyOrder(200,409);
        }
        assertThat(jdbc.queryForObject("select experiencia from personagens where id=?",Long.class,p)).isEqualTo(150);
    }

    @Test void conquistaNaoPodeSerDuplicadaEExigeAdministrador() throws Exception {
        long j=jogador(jogador), c=criar("/conquistas",admin,dados("conquistas","Veterano"));
        String base="/jogadores/"+j+"/conquistas/"+c;
        chamada("POST",base,jogador,null).andExpect(status().isForbidden());
        chamada("POST",base,admin,null).andExpect(status().isCreated());
        chamada("POST",base,admin,null).andExpect(status().isConflict());
        chamada("GET","/jogadores/"+j+"/conquistas",jogador,null).andExpect(status().isOk()).andExpect(jsonPath("$[0].conquistaId").value(c));
        chamada("DELETE","/conquistas/"+c,admin,null).andExpect(status().isConflict());
        chamada("DELETE",base,admin,null).andExpect(status().isNoContent());
        chamada("DELETE","/conquistas/"+c,admin,null).andExpect(status().isNoContent());
    }

    @Test void excluirJogadorRemoveDependenciasSemApagarCatalogosOuConta() throws Exception {
        long p=personagem(jogador), j=jdbc.queryForObject("select jogador_id from personagens where id=?",Long.class,p);
        long i=criar("/itens",admin,dados("itens","Item")), m=criar("/missoes",admin,dados("missoes","Missão")), c=criar("/conquistas",admin,dados("conquistas","Medalha"));
        chamada("POST","/personagens/"+p+"/inventario/itens",jogador,Map.of("itemId",i,"quantidade",1)).andExpect(status().isOk());
        chamada("POST","/personagens/"+p+"/missoes/"+m,jogador,null).andExpect(status().isCreated());
        chamada("POST","/jogadores/"+j+"/conquistas/"+c,admin,null).andExpect(status().isCreated());
        chamada("DELETE","/jogadores/"+j,jogador,null).andExpect(status().isNoContent());
        for (String table : List.of("personagens","inventarios","itens_inventario","personagens_missoes","jogadores_conquistas"))
            assertThat(jdbc.queryForObject("select count(*) from "+table,Long.class)).isZero();
        chamada("GET","/itens/"+i,jogador,null).andExpect(status().isOk());
        chamada("GET","/missoes/"+m,jogador,null).andExpect(status().isOk());
        chamada("GET","/conquistas/"+c,jogador,null).andExpect(status().isOk());
        chamada("GET","/auth/me",jogador,null).andExpect(status().isOk());
    }

    @Test void validacoesEErrosSaoPadronizados() throws Exception {
        chamada("POST","/jogadores",jogador,Map.of("nome","   ")).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.nome").exists());
        chamada("POST","/personagens",jogador,Map.of("nome","Herói","classe","Mago")).andExpect(status().isNotFound());
        chamada("POST","/itens",admin,Map.of("nome","Item","descricao","D","tipo","A","valor",-1)).andExpect(status().isBadRequest());
        chamada("POST","/missoes",admin,Map.of("nome","Missão","descricao","D","recompensaXp",-1)).andExpect(status().isBadRequest());
        chamada("POST","/conquistas",admin,Map.of("nome"," ","descricao","D")).andExpect(status().isBadRequest());
        chamada("GET","/itens/-1",jogador,null).andExpect(status().isBadRequest());
        chamada("GET","/itens/999999",jogador,null).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404)).andExpect(jsonPath("$.message").exists())
                .andExpect(jsonPath("$.path").value("/itens/999999"));
        mvc.perform(post("/itens").header("Authorization","Bearer "+admin).contentType("application/json").content("{"))
                .andExpect(status().isBadRequest());
    }

    @Test void bancoImpoeChavesEstrangeirasERestricoes() {
        assertThatThrownBy(() -> jdbc.update("insert into personagens(jogador_id,nome,classe,nivel,experiencia) values (999999,'P','Mago',1,0)"))
                .isInstanceOf(DataIntegrityViolationException.class);
        assertThatThrownBy(() -> jdbc.update("insert into itens(nome,descricao,tipo,valor) values ('I','D','T',-1)"))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test void swaggerPublicoDocumentaOsCincoCruds() throws Exception {
        var api=resposta(chamada("GET","/v3/api-docs",null,null),200);
        for (String path : List.of("/jogadores","/personagens","/itens","/missoes","/conquistas")) {
            assertThat(api.path("paths").path(path).has("post")).isTrue();
            assertThat(api.path("paths").path(path+"/{id}").has("delete")).isTrue();
            assertThat(api.path("paths").path(path).path("post").path("responses").has("201")).isTrue();
        }
        assertThat(api.path("components").path("securitySchemes").has("bearerAuth")).isTrue();
    }
}
