package com.example.security.dto.response;

public record ItemResponse(Long id, String nome, String descricao, String tipo, java.math.BigDecimal valor) {}
