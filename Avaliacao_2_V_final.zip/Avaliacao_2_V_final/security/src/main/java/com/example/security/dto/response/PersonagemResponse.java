package com.example.security.dto.response;

public record PersonagemResponse(Long id, Long jogadorId, String nome, String classe, Integer nivel, Long experiencia) {}
