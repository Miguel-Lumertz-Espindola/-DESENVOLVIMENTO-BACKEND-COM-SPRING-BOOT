package com.example.security.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.*;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springframework.context.annotation.*;

@Configuration
public class OpenApiConfig {
    @Bean public OpenAPI customOpenAPI() {
        var error = new ObjectSchema()
                .addProperty("timestamp", new StringSchema().format("date-time"))
                .addProperty("status", new IntegerSchema())
                .addProperty("message", new StringSchema())
                .addProperty("path", new StringSchema())
                .addProperty("fieldErrors", new ObjectSchema());
        return new OpenAPI().info(new Info().title("GuildaQuest - API de gerenciamento de jogo")
                .description("Jogadores, personagens, inventários, missões e conquistas. "
                        + "Catálogos são gerenciados por ADMIN. Jogadores acessam seus próprios dados. "
                        + "Listagens principais usam page/size (máximo 100) e ordenação por ID.")
                .version("1.0"))
                .components(new Components().addSchemas("ApiError", error)
                        .addSecuritySchemes("bearerAuth", new SecurityScheme()
                                .type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")));
    }
    @Bean OpenApiCustomizer errosPadronizados() {
        return api -> api.getPaths().values().forEach(path -> path.readOperations().forEach(op -> {
            for (String status : new String[]{"400", "401", "403", "404", "409"}) {
                if (!op.getResponses().containsKey(status)) {
                    op.getResponses().addApiResponse(status, new ApiResponse()
                            .description(switch (status) {
                                case "400" -> "Entrada inválida";
                                case "401" -> "Autenticação ausente ou inválida";
                                case "403" -> "Operação sem permissão";
                                case "404" -> "Recurso não encontrado, quando aplicável";
                                default -> "Conflito de negócio ou vínculo, quando aplicável";
                            })
                            .content(new Content().addMediaType("application/json", new MediaType()
                                    .schema(new Schema<>().$ref("#/components/schemas/ApiError")))));
                }
            }
        }));
    }
}
