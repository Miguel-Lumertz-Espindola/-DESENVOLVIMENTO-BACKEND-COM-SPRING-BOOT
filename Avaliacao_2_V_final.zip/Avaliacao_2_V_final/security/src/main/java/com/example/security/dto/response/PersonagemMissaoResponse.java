package com.example.security.dto.response;

public record PersonagemMissaoResponse(Long missaoId, String nome, com.example.security.entity.StatusMissao status, java.time.LocalDate dataInicio, java.time.LocalDate dataConclusao, Long recompensaXp) {}
