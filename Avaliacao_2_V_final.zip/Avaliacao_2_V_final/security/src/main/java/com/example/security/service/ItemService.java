package com.example.security.service;

import com.example.security.entity.Item;
import com.example.security.repository.*;
import com.example.security.dto.request.ItemRequest;
import com.example.security.dto.response.*;
import com.example.security.exception.NotFoundException;
import com.example.security.validation.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.data.domain.Pageable;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class ItemService {
    private final ItemRepository repository;
    private final ItemInventarioRepository associacoes;
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public ItemResponse criar(ItemRequest request) {
        var i = new Item(); preencher(i, request);
        return GameMapper.item(repository.saveAndFlush(i));
    }
    public PaginaResponse<ItemResponse> listar(Pageable pagina) {
        return PaginaResponse.de(repository.findAll(Paginacao.normalizar(pagina)).map(GameMapper::item));
    }
    public ItemResponse buscar(Long id) { return GameMapper.item(carregar(id)); }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public ItemResponse atualizar(Long id, ItemRequest request) {
        var i = carregar(id); preencher(i, request); return GameMapper.item(i);
    }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public void excluir(Long id) {
        var i = carregar(id);
        RegrasJogo.exigir(!associacoes.existsByItemId(id), "Registro vinculado ao jogo; remova os vínculos antes de excluir");
        repository.delete(i);
    }
    public Item carregar(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Item não encontrado(a)"));
    }
    private void preencher(Item i, ItemRequest request) { i.setNome(request.nome().strip()); i.setDescricao(request.descricao().strip()); i.setTipo(request.tipo().strip()); i.setValor(request.valor()); }
}
