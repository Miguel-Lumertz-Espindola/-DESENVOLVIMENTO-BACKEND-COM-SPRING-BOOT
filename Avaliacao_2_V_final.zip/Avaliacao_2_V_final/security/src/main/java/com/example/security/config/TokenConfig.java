package com.example.security.config;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.example.security.entity.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.time.Instant;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Component
public class TokenConfig {
    private final Algorithm algorithm;
    private final long expiration;
    public TokenConfig(@Value("${api.security.jwt.secret}") String secret,
                       @Value("${api.security.jwt.expiration-seconds:3600}") long expiration) {
        if (secret.getBytes(StandardCharsets.UTF_8).length < 32 || expiration <= 0)
            throw new IllegalArgumentException("JWT_SECRET deve ter ao menos 32 bytes e a duração deve ser positiva");
        this.algorithm = Algorithm.HMAC256(secret);
        this.expiration = expiration;
    }
    public String generateToken(User user) {
        return JWT.create().withIssuer("guilda-quest").withSubject(user.getEmail())
                .withClaim("userId", user.getId()).withIssuedAt(Instant.now())
                .withExpiresAt(Instant.now().plusSeconds(expiration)).sign(algorithm);
    }
    public Optional<Long> validateToken(String token) {
        try {
            var decoded = JWT.require(algorithm).withIssuer("guilda-quest").build().verify(token);
            Long id = decoded.getClaim("userId").asLong();
            return id != null && id > 0 ? Optional.of(id) : Optional.empty();
        } catch (JWTVerificationException | IllegalArgumentException ex) {
            return Optional.empty();
        }
    }
}
