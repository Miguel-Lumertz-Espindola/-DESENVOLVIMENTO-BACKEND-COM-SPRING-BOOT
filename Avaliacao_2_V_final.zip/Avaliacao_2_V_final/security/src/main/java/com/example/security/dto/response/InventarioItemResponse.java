package com.example.security.dto.response;

public record InventarioItemResponse(Long itemId, String nome, Integer quantidade) {}
