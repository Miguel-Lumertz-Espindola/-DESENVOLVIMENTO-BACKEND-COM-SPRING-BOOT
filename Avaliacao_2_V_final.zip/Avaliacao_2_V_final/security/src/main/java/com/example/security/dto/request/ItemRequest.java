package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record ItemRequest(@NotBlank @Size(max = 150) String nome, @NotBlank @Size(max = 1000) String descricao, @NotBlank @Size(max = 50) String tipo, @NotNull @DecimalMin("0.00") @Digits(integer = 10, fraction = 2) java.math.BigDecimal valor) {}
