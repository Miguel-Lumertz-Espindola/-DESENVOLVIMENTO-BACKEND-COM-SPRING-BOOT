package com.example.security.dto.response;

public record MissaoResponse(Long id, String nome, String descricao, Long recompensaXp) {}
