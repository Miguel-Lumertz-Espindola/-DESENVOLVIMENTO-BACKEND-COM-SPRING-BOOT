package com.example.security.service;

import com.example.security.entity.Conquista;
import com.example.security.repository.*;
import com.example.security.dto.request.ConquistaRequest;
import com.example.security.dto.response.*;
import com.example.security.exception.NotFoundException;
import com.example.security.validation.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.data.domain.Pageable;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class ConquistaService {
    private final ConquistaRepository repository;
    private final JogadorConquistaRepository associacoes;
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public ConquistaResponse criar(ConquistaRequest request) {
        var i = new Conquista(); preencher(i, request);
        return GameMapper.conquista(repository.saveAndFlush(i));
    }
    public PaginaResponse<ConquistaResponse> listar(Pageable pagina) {
        return PaginaResponse.de(repository.findAll(Paginacao.normalizar(pagina)).map(GameMapper::conquista));
    }
    public ConquistaResponse buscar(Long id) { return GameMapper.conquista(carregar(id)); }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public ConquistaResponse atualizar(Long id, ConquistaRequest request) {
        var i = carregar(id); preencher(i, request); return GameMapper.conquista(i);
    }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public void excluir(Long id) {
        var i = carregar(id);
        RegrasJogo.exigir(!associacoes.existsByConquistaId(id), "Registro vinculado ao jogo; remova os vínculos antes de excluir");
        repository.delete(i);
    }
    public Conquista carregar(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Conquista não encontrado(a)"));
    }
    private void preencher(Conquista i, ConquistaRequest request) { i.setNome(request.nome().strip()); i.setDescricao(request.descricao().strip()); }
}
