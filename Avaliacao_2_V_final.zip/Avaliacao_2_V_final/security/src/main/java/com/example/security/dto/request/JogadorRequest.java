package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record JogadorRequest(@NotBlank @Size(max = 150) String nome) {}
