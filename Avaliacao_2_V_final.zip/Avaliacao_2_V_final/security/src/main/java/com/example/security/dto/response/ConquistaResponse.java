package com.example.security.dto.response;

public record ConquistaResponse(Long id, String nome, String descricao) {}
