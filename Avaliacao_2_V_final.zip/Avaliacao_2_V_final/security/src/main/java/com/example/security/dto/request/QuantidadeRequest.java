package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record QuantidadeRequest(@NotNull @Min(1) @Max(1000000) Integer quantidade) {}
