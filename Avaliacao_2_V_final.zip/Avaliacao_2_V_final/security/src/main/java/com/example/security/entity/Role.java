package com.example.security.entity;

public enum Role { JOGADOR, ADMIN }
