package com.example.security.controller;

import com.example.security.dto.request.ItemRequest;
import com.example.security.dto.response.*;
import com.example.security.service.ItemService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Pageable;
import org.springdoc.core.annotations.ParameterObject;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.net.URI;

@RestController @RequestMapping("/itens") @RequiredArgsConstructor
@Tag(name = "Itens") @SecurityRequirement(name = "bearerAuth")
public class ItemController {
    private final ItemService service;
    @PostMapping @ApiResponse(responseCode = "201", description = "Criado") @Operation(summary = "Cria item (ADMIN)")
    public ResponseEntity<ItemResponse> criar(@Valid @RequestBody ItemRequest request) {
        var result = service.criar(request);
        return ResponseEntity.created(URI.create("/itens/" + result.id())).body(result);
    }
    @GetMapping @Operation(summary = "Lista itens com paginação e ordenação por ID")
    public PaginaResponse<ItemResponse> listar(@ParameterObject Pageable pagina) { return service.listar(pagina); }
    @GetMapping("/{id}") @Operation(summary = "Busca item por ID")
    public ItemResponse buscar(@PathVariable @Positive Long id) { return service.buscar(id); }
    @PutMapping("/{id}") @Operation(summary = "Atualiza item (ADMIN)")
    public ItemResponse atualizar(@PathVariable @Positive Long id, @Valid @RequestBody ItemRequest request) {
        return service.atualizar(id, request);
    }
    @DeleteMapping("/{id}") @ApiResponse(responseCode = "204", description = "Excluído") @Operation(summary = "Exclui item (ADMIN)")
    public ResponseEntity<Void> excluir(@PathVariable @Positive Long id) {
        service.excluir(id); return ResponseEntity.noContent().build();
    }
}
