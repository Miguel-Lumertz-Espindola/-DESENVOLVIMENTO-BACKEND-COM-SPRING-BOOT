package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "itens_inventario")
        public class ItemInventario {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "inventario_id", nullable = false) private Inventario inventario;
@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "item_id", nullable = false) private Item item;
@Column(nullable = false) private Integer quantidade;
        }
