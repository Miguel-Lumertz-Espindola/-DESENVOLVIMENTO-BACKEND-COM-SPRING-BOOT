package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record MissaoRequest(@NotBlank @Size(max = 150) String nome, @NotBlank @Size(max = 1000) String descricao, @NotNull @Min(0) @Max(1000000) Long recompensaXp) {}
