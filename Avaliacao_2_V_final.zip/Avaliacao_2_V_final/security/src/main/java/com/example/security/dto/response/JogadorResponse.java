package com.example.security.dto.response;

public record JogadorResponse(Long id, Long userId, String nome) {}
