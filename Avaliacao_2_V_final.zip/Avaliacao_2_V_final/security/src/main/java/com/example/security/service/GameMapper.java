package com.example.security.service;

import com.example.security.entity.*;
import com.example.security.dto.response.*;

public final class GameMapper {
    private GameMapper() {}
    public static JogadorResponse jogador(Jogador j) {
        return new JogadorResponse(j.getId(), j.getUser().getId(), j.getNome());
    }
    public static PersonagemResponse personagem(Personagem p) {
        return new PersonagemResponse(p.getId(), p.getJogador().getId(), p.getNome(),
                p.getClasse(), p.getNivel(), p.getExperiencia());
    }
    public static ItemResponse item(Item i) {
        return new ItemResponse(i.getId(), i.getNome(), i.getDescricao(), i.getTipo(), i.getValor());
    }
    public static MissaoResponse missao(Missao m) {
        return new MissaoResponse(m.getId(), m.getNome(), m.getDescricao(), m.getRecompensaXp());
    }
    public static ConquistaResponse conquista(Conquista c) {
        return new ConquistaResponse(c.getId(), c.getNome(), c.getDescricao());
    }
    public static PersonagemMissaoResponse progresso(PersonagemMissao p) {
        return new PersonagemMissaoResponse(p.getMissao().getId(), p.getMissao().getNome(),
                p.getStatus(), p.getDataInicio(), p.getDataConclusao(), p.getRecompensaXp());
    }
}
