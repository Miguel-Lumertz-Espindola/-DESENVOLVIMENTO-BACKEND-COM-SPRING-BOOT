package com.example.security.service;

import com.example.security.entity.*;
import com.example.security.repository.*;
import com.example.security.dto.request.PersonagemRequest;
import com.example.security.dto.response.*;
import com.example.security.exception.NotFoundException;
import com.example.security.validation.Paginacao;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Pageable;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class PersonagemService {
    private final PersonagemRepository repository;
    private final InventarioRepository inventarios;
    private final JogadorService jogadores;
    private final AcessoService acesso;
    @Transactional public PersonagemResponse criar(PersonagemRequest request) {
        var personagem = new Personagem(); personagem.setJogador(jogadores.atual());
        personagem.setNome(request.nome().strip()); personagem.setClasse(request.classe().strip());
        repository.saveAndFlush(personagem);
        var inventario = new Inventario(); inventario.setPersonagem(personagem);
        inventarios.save(inventario);
        return GameMapper.personagem(personagem);
    }
    public PaginaResponse<PersonagemResponse> listar(Pageable pagina) {
        var p = Paginacao.normalizar(pagina);
        var result = acesso.admin() ? repository.findAll(p)
                : repository.findByJogadorUserId(acesso.usuario().getId(), p);
        return PaginaResponse.de(result.map(GameMapper::personagem));
    }
    public PersonagemResponse buscar(Long id) { return GameMapper.personagem(carregar(id)); }
    @Transactional public PersonagemResponse atualizar(Long id, PersonagemRequest request) {
        var p = bloquear(id); p.setNome(request.nome().strip()); p.setClasse(request.classe().strip());
        return GameMapper.personagem(p);
    }
    @Transactional public void excluir(Long id) { repository.delete(bloquear(id)); }
    public Personagem carregar(Long id) {
        var p = repository.findById(id).orElseThrow(() -> new NotFoundException("Personagem não encontrado"));
        acesso.proprietario(p.getJogador()); return p;
    }
    public Personagem bloquear(Long id) {
        var p = repository.findForUpdate(id).orElseThrow(() -> new NotFoundException("Personagem não encontrado"));
        acesso.proprietario(p.getJogador()); return p;
    }
}
