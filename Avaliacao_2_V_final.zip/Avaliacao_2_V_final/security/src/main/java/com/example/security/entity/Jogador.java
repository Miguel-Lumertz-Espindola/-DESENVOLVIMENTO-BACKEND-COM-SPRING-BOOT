package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "jogadores")
        public class Jogador {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @OneToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "user_id", nullable = false, unique = true)
private User user;
@Column(nullable = false, length = 150)
private String nome;
        }
