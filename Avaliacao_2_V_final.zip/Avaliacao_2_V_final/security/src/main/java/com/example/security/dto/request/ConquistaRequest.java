package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record ConquistaRequest(@NotBlank @Size(max = 150) String nome, @NotBlank @Size(max = 1000) String descricao) {}
