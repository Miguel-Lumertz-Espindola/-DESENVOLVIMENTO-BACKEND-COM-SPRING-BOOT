package com.example.security.validation;

import com.example.security.exception.BusinessException;
public final class RegrasJogo {
    private RegrasJogo() {}
    public static void exigir(boolean condicao, String mensagem) {
        if (!condicao) throw new BusinessException(mensagem);
    }
    public static int nivelPara(long experiencia) {
        return Math.toIntExact(1 + experiencia / 100);
    }
}
