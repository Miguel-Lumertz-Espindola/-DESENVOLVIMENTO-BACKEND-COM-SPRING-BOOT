package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record LoginRequest(@NotBlank @Email @Size(max = 250) String email, @NotBlank @Size(max = 72) String password) {}
