package com.example.security.service;

import com.example.security.entity.Jogador;
import com.example.security.repository.JogadorRepository;
import com.example.security.dto.request.JogadorRequest;
import com.example.security.dto.response.*;
import com.example.security.exception.NotFoundException;
import com.example.security.validation.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Pageable;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class JogadorService {
    private final JogadorRepository repository;
    private final AcessoService acesso;
    @Transactional public JogadorResponse criar(JogadorRequest request) {
        var user = acesso.usuario();
        RegrasJogo.exigir(!repository.existsByUserId(user.getId()), "Esta conta já possui um jogador");
        var jogador = new Jogador();
        jogador.setUser(user); jogador.setNome(request.nome().strip());
        return GameMapper.jogador(repository.saveAndFlush(jogador));
    }
    public PaginaResponse<JogadorResponse> listar(Pageable pagina) {
        var p = Paginacao.normalizar(pagina);
        var result = acesso.admin() ? repository.findAll(p)
                : repository.findAllByUserId(acesso.usuario().getId(), p);
        return PaginaResponse.de(result.map(GameMapper::jogador));
    }
    public JogadorResponse buscar(Long id) { return GameMapper.jogador(carregar(id)); }
    @Transactional public JogadorResponse atualizar(Long id, JogadorRequest request) {
        var jogador = carregar(id); jogador.setNome(request.nome().strip());
        return GameMapper.jogador(jogador);
    }
    @Transactional public void excluir(Long id) { repository.delete(carregar(id)); }
    public Jogador carregar(Long id) {
        var jogador = repository.findById(id).orElseThrow(() -> new NotFoundException("Jogador não encontrado"));
        acesso.proprietario(jogador); return jogador;
    }
    public Jogador atual() {
        return repository.findByUserId(acesso.usuario().getId())
                .orElseThrow(() -> new NotFoundException("Crie seu perfil em POST /jogadores antes de criar personagens"));
    }
}
