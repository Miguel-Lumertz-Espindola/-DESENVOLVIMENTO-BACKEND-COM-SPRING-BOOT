package com.example.security.controller;

import com.example.security.dto.request.*;
import com.example.security.dto.response.InventarioResponse;
import com.example.security.service.InventarioService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController @RequestMapping("/personagens/{personagemId}/inventario") @RequiredArgsConstructor
@Tag(name = "Inventário") @SecurityRequirement(name = "bearerAuth")
public class InventarioController {
    private final InventarioService service;
    @GetMapping @Operation(summary = "Consulta inventário do personagem")
    public InventarioResponse buscar(@PathVariable @Positive Long personagemId) { return service.buscar(personagemId); }
    @PutMapping @Operation(summary = "Altera capacidade sem descartar itens existentes")
    public InventarioResponse atualizar(@PathVariable @Positive Long personagemId, @Valid @RequestBody InventarioRequest r) {
        return service.atualizar(personagemId, r);
    }
    @PostMapping("/itens") @Operation(summary = "Adiciona item ou incrementa quantidade")
    public InventarioResponse adicionar(@PathVariable @Positive Long personagemId, @Valid @RequestBody InventarioItemRequest r) {
        return service.adicionar(personagemId, r);
    }
    @PutMapping("/itens/{itemId}") @Operation(summary = "Define quantidade de um item")
    public InventarioResponse quantidade(@PathVariable @Positive Long personagemId, @PathVariable @Positive Long itemId,
                                         @Valid @RequestBody QuantidadeRequest r) {
        return service.quantidade(personagemId, itemId, r);
    }
    @DeleteMapping("/itens/{itemId}") @Operation(summary = "Remove item do inventário")
    public ResponseEntity<Void> remover(@PathVariable @Positive Long personagemId, @PathVariable @Positive Long itemId) {
        service.remover(personagemId, itemId); return ResponseEntity.noContent().build();
    }
}
