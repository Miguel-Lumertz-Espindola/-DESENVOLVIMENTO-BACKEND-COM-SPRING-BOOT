package com.example.security.dto.response;

public record InventarioResponse(Long id, Long personagemId, Integer capacidade, java.util.List<InventarioItemResponse> itens) {}
