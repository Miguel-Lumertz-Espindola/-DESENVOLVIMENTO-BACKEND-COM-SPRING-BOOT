package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "personagens_missoes")
        public class PersonagemMissao {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "personagem_id", nullable = false) private Personagem personagem;
@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "missao_id", nullable = false) private Missao missao;
@Enumerated(EnumType.STRING) @Column(nullable = false, length = 30)
private StatusMissao status = StatusMissao.EM_ANDAMENTO;
@Column(name = "data_inicio", nullable = false) private java.time.LocalDate dataInicio;
@Column(name = "data_conclusao") private java.time.LocalDate dataConclusao;
@Column(name = "recompensa_xp", nullable = false) private Long recompensaXp;
        }
