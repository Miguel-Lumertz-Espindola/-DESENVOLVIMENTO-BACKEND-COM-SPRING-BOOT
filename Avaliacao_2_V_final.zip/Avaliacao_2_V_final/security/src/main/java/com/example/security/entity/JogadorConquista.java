package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "jogadores_conquistas")
        public class JogadorConquista {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "jogador_id", nullable = false) private Jogador jogador;
@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "conquista_id", nullable = false) private Conquista conquista;
@Column(name = "data_obtencao", nullable = false) private java.time.LocalDate dataObtencao;
        }
