package com.example.security.exception;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.ConcurrencyFailureException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import java.time.Instant;
import java.util.LinkedHashMap;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ApiError> validation(MethodArgumentNotValidException ex, HttpServletRequest r) {
        var fields = new LinkedHashMap<String, String>();
        ex.getBindingResult().getFieldErrors().forEach(e -> fields.putIfAbsent(e.getField(), e.getDefaultMessage()));
        return ResponseEntity.badRequest().body(new ApiError(Instant.now(), 400,
                "Dados inválidos", r.getRequestURI(), fields));
    }
    @ExceptionHandler({HttpMessageNotReadableException.class, ConstraintViolationException.class,
            HandlerMethodValidationException.class, MethodArgumentTypeMismatchException.class,
            IllegalArgumentException.class})
    ResponseEntity<ApiError> invalid(Exception ex, HttpServletRequest r) {
        return error(400, "Requisição inválida; confira os campos e seus limites", r);
    }
    @ExceptionHandler({NotFoundException.class, NoResourceFoundException.class})
    ResponseEntity<ApiError> notFound(Exception ex, HttpServletRequest r) {
        return error(404, ex instanceof NotFoundException ? ex.getMessage() : "Rota não encontrada", r);
    }
    @ExceptionHandler(BusinessException.class)
    ResponseEntity<ApiError> conflict(BusinessException ex, HttpServletRequest r) {
        return error(409, ex.getMessage(), r);
    }
    @ExceptionHandler({DataIntegrityViolationException.class, ConcurrencyFailureException.class})
    ResponseEntity<ApiError> integrity(Exception ex, HttpServletRequest r) {
        return error(409, "Operação em conflito com os dados existentes; confira vínculos e duplicidades", r);
    }
    @ExceptionHandler(AuthenticationException.class)
    ResponseEntity<ApiError> unauthenticated(Exception ex, HttpServletRequest r) {
        return error(401, "Credenciais inválidas", r);
    }
    @ExceptionHandler(AccessDeniedException.class)
    ResponseEntity<ApiError> denied(Exception ex, HttpServletRequest r) {
        return error(403, "Você não tem permissão para esta operação", r);
    }
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    ResponseEntity<ApiError> method(Exception ex, HttpServletRequest r) {
        return error(405, "Método HTTP não permitido", r);
    }
    @ExceptionHandler(Exception.class)
    ResponseEntity<ApiError> unexpected(Exception ex, HttpServletRequest r) {
        log.error("Falha inesperada em {}", r.getRequestURI(), ex);
        return error(500, "Erro interno ao processar a operação", r);
    }
    private ResponseEntity<ApiError> error(int status, String message, HttpServletRequest r) {
        return ResponseEntity.status(status).body(ApiError.of(status, message, r.getRequestURI()));
    }
}
