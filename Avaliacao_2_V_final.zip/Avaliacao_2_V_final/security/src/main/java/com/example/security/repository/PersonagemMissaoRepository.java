package com.example.security.repository;

import com.example.security.entity.PersonagemMissao;
        import org.springframework.data.jpa.repository.*;
        import org.springframework.data.domain.*;
        import org.springframework.data.repository.query.Param;
        import jakarta.persistence.LockModeType;
        import java.util.*;

        public interface PersonagemMissaoRepository extends JpaRepository<PersonagemMissao, Long> {
            Optional<PersonagemMissao> findByPersonagemIdAndMissaoId(Long personagemId, Long missaoId);
List<PersonagemMissao> findByPersonagemIdOrderByIdAsc(Long personagemId);
boolean existsByMissaoId(Long missaoId);
        }
