package com.example.security.repository;

import com.example.security.entity.Jogador;
        import org.springframework.data.jpa.repository.*;
        import org.springframework.data.domain.*;
        import org.springframework.data.repository.query.Param;
        import jakarta.persistence.LockModeType;
        import java.util.*;

        public interface JogadorRepository extends JpaRepository<Jogador, Long> {
            Optional<Jogador> findByUserId(Long userId);
boolean existsByUserId(Long userId);
    Page<Jogador> findAllByUserId(Long userId, Pageable pageable);
        }
