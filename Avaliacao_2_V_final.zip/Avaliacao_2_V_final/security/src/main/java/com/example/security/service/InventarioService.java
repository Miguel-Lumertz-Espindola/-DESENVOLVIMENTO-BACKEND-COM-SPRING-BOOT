package com.example.security.service;

import com.example.security.entity.*;
import com.example.security.repository.*;
import com.example.security.dto.request.*;
import com.example.security.dto.response.*;
import com.example.security.exception.NotFoundException;
import com.example.security.validation.RegrasJogo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class InventarioService {
    private final InventarioRepository inventarios;
    private final ItemInventarioRepository itens;
    private final ItemService catalogo;
    private final PersonagemService personagens;
    public InventarioResponse buscar(Long personagemId) {
        personagens.carregar(personagemId); return resposta(carregar(personagemId));
    }
    @Transactional public InventarioResponse atualizar(Long personagemId, InventarioRequest request) {
        personagens.bloquear(personagemId);
        var inventario = carregar(personagemId);
        RegrasJogo.exigir(request.capacidade() >= itens.countByInventarioId(inventario.getId()),
                "Capacidade inferior à quantidade de itens distintos armazenados");
        inventario.setCapacidade(request.capacidade()); return resposta(inventario);
    }
    @Transactional public InventarioResponse adicionar(Long personagemId, InventarioItemRequest request) {
        personagens.bloquear(personagemId);
        var inventario = carregar(personagemId);
        var existente = itens.findByInventarioIdAndItemId(inventario.getId(), request.itemId());
        if (existente.isPresent()) {
            long total = (long) existente.get().getQuantidade() + request.quantidade();
            RegrasJogo.exigir(total <= 1000000, "Quantidade máxima por item excedida");
            existente.get().setQuantidade((int) total);
        } else {
            var item = catalogo.carregar(request.itemId());
            RegrasJogo.exigir(itens.countByInventarioId(inventario.getId()) < inventario.getCapacidade(),
                    "Inventário sem espaço para outro item distinto");
            var link = new ItemInventario(); link.setInventario(inventario); link.setItem(item);
            link.setQuantidade(request.quantidade()); itens.saveAndFlush(link);
        }
        return resposta(inventario);
    }
    @Transactional public InventarioResponse quantidade(Long personagemId, Long itemId, QuantidadeRequest request) {
        personagens.bloquear(personagemId); var inventario = carregar(personagemId);
        var link = itens.findByInventarioIdAndItemId(inventario.getId(), itemId)
                .orElseThrow(() -> new NotFoundException("Item não está neste inventário"));
        link.setQuantidade(request.quantidade()); return resposta(inventario);
    }
    @Transactional public void remover(Long personagemId, Long itemId) {
        personagens.bloquear(personagemId); var inventario = carregar(personagemId);
        var link = itens.findByInventarioIdAndItemId(inventario.getId(), itemId)
                .orElseThrow(() -> new NotFoundException("Item não está neste inventário"));
        itens.delete(link);
    }
    private Inventario carregar(Long personagemId) {
        return inventarios.findByPersonagemId(personagemId)
                .orElseThrow(() -> new NotFoundException("Inventário não encontrado"));
    }
    private InventarioResponse resposta(Inventario i) {
        var conteudo = itens.findByInventarioIdOrderByIdAsc(i.getId()).stream()
                .map(l -> new InventarioItemResponse(l.getItem().getId(), l.getItem().getNome(), l.getQuantidade())).toList();
        return new InventarioResponse(i.getId(), i.getPersonagem().getId(), i.getCapacidade(), conteudo);
    }
}
