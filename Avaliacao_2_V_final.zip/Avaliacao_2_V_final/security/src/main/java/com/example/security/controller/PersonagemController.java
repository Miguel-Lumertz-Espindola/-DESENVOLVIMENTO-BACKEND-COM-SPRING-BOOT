package com.example.security.controller;

import com.example.security.dto.request.PersonagemRequest;
import com.example.security.dto.response.*;
import com.example.security.service.PersonagemService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Pageable;
import org.springdoc.core.annotations.ParameterObject;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.net.URI;

@RestController @RequestMapping("/personagens") @RequiredArgsConstructor
@Tag(name = "Personagens") @SecurityRequirement(name = "bearerAuth")
public class PersonagemController {
    private final PersonagemService service;
    @PostMapping @ApiResponse(responseCode = "201", description = "Criado") @Operation(summary = "Cria personagem")
    public ResponseEntity<PersonagemResponse> criar(@Valid @RequestBody PersonagemRequest request) {
        var result = service.criar(request);
        return ResponseEntity.created(URI.create("/personagens/" + result.id())).body(result);
    }
    @GetMapping @Operation(summary = "Lista personagens com paginação e ordenação por ID")
    public PaginaResponse<PersonagemResponse> listar(@ParameterObject Pageable pagina) { return service.listar(pagina); }
    @GetMapping("/{id}") @Operation(summary = "Busca personagem por ID")
    public PersonagemResponse buscar(@PathVariable @Positive Long id) { return service.buscar(id); }
    @PutMapping("/{id}") @Operation(summary = "Atualiza personagem")
    public PersonagemResponse atualizar(@PathVariable @Positive Long id, @Valid @RequestBody PersonagemRequest request) {
        return service.atualizar(id, request);
    }
    @DeleteMapping("/{id}") @ApiResponse(responseCode = "204", description = "Excluído") @Operation(summary = "Exclui personagem")
    public ResponseEntity<Void> excluir(@PathVariable @Positive Long id) {
        service.excluir(id); return ResponseEntity.noContent().build();
    }
}
