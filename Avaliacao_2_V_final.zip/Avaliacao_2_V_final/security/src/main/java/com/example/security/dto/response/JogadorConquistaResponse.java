package com.example.security.dto.response;

public record JogadorConquistaResponse(Long conquistaId, String nome, String descricao, java.time.LocalDate dataObtencao) {}
