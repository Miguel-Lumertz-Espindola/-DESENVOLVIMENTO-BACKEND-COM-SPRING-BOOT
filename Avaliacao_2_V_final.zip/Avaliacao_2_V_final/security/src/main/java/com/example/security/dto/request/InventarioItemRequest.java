package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record InventarioItemRequest(@NotNull @Positive Long itemId, @NotNull @Min(1) @Max(1000000) Integer quantidade) {}
