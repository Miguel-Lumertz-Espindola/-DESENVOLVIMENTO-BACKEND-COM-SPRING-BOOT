package com.example.security.service;

import com.example.security.entity.Missao;
import com.example.security.repository.*;
import com.example.security.dto.request.MissaoRequest;
import com.example.security.dto.response.*;
import com.example.security.exception.NotFoundException;
import com.example.security.validation.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.data.domain.Pageable;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class MissaoService {
    private final MissaoRepository repository;
    private final PersonagemMissaoRepository associacoes;
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public MissaoResponse criar(MissaoRequest request) {
        var i = new Missao(); preencher(i, request);
        return GameMapper.missao(repository.saveAndFlush(i));
    }
    public PaginaResponse<MissaoResponse> listar(Pageable pagina) {
        return PaginaResponse.de(repository.findAll(Paginacao.normalizar(pagina)).map(GameMapper::missao));
    }
    public MissaoResponse buscar(Long id) { return GameMapper.missao(carregar(id)); }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public MissaoResponse atualizar(Long id, MissaoRequest request) {
        var i = carregar(id); preencher(i, request); return GameMapper.missao(i);
    }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public void excluir(Long id) {
        var i = carregar(id);
        RegrasJogo.exigir(!associacoes.existsByMissaoId(id), "Registro vinculado ao jogo; remova os vínculos antes de excluir");
        repository.delete(i);
    }
    public Missao carregar(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Missao não encontrado(a)"));
    }
    private void preencher(Missao i, MissaoRequest request) { i.setNome(request.nome().strip()); i.setDescricao(request.descricao().strip()); i.setRecompensaXp(request.recompensaXp()); }
}
