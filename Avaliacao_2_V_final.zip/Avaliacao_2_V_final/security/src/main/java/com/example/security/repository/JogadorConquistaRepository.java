package com.example.security.repository;

import com.example.security.entity.JogadorConquista;
        import org.springframework.data.jpa.repository.*;
        import org.springframework.data.domain.*;
        import org.springframework.data.repository.query.Param;
        import jakarta.persistence.LockModeType;
        import java.util.*;

        public interface JogadorConquistaRepository extends JpaRepository<JogadorConquista, Long> {
            boolean existsByJogadorIdAndConquistaId(Long jogadorId, Long conquistaId);
List<JogadorConquista> findByJogadorIdOrderByIdAsc(Long jogadorId);
boolean existsByConquistaId(Long conquistaId);
        }
