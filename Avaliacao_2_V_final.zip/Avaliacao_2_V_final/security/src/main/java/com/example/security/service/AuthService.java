package com.example.security.service;

import com.example.security.config.TokenConfig;
import com.example.security.dto.request.*;
import com.example.security.dto.response.*;
import com.example.security.entity.User;
import com.example.security.repository.UserRepository;
import com.example.security.validation.RegrasJogo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

@Service @RequiredArgsConstructor
public class AuthService {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final AuthenticationManager manager;
    private final TokenConfig tokens;
    public LoginResponse login(LoginRequest request) {
        var auth = manager.authenticate(new UsernamePasswordAuthenticationToken(
                request.email().strip().toLowerCase(Locale.ROOT), request.password()));
        return new LoginResponse(tokens.generateToken((User) auth.getPrincipal()));
    }
    @Transactional
    public RegisterUserResponse register(RegisterUserRequest request) {
        String email = request.email().strip().toLowerCase(Locale.ROOT);
        RegrasJogo.exigir(!users.existsByEmailIgnoreCase(email), "E-mail já cadastrado");
        // BCrypt limita a entrada por bytes, não por quantidade de caracteres Unicode.
        if (request.password().getBytes(StandardCharsets.UTF_8).length > 72)
            throw new IllegalArgumentException("Senha deve ter até 72 bytes em UTF-8");
        User user = new User();
        user.setName(request.name().strip()); user.setEmail(email);
        user.setPassword(encoder.encode(request.password()));
        users.saveAndFlush(user);
        return new RegisterUserResponse(user.getName(), user.getEmail());
    }
}
