package com.example.security.config;

import com.example.security.repository.UserRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

@Component @RequiredArgsConstructor
public class SecurityFilter extends OncePerRequestFilter {
    private final TokenConfig tokens;
    private final UserRepository users;
    private final SecurityErrorWriter errors;
    @Override protected boolean shouldNotFilter(HttpServletRequest r) {
        String p = r.getRequestURI().substring(r.getContextPath().length());
        return p.startsWith("/swagger-ui") || p.startsWith("/v3/api-docs")
                || ("POST".equals(r.getMethod()) && (p.equals("/auth/login") || p.equals("/auth/register")));
    }
    @Override protected void doFilterInternal(HttpServletRequest r, HttpServletResponse s,
                                             FilterChain chain) throws ServletException, IOException {
        String header = r.getHeader("Authorization");
        if (header != null) {
            var id = header.startsWith("Bearer ") ? tokens.validateToken(header.substring(7)) : java.util.Optional.<Long>empty();
            var user = id.flatMap(users::findById);
            if (user.isEmpty()) {
                SecurityContextHolder.clearContext();
                errors.write(r, s, 401, "Token inválido ou expirado"); return;
            }
            var u = user.get();
            SecurityContextHolder.getContext().setAuthentication(
                    new UsernamePasswordAuthenticationToken(u, null, u.getAuthorities()));
        }
        chain.doFilter(r, s);
    }
}
