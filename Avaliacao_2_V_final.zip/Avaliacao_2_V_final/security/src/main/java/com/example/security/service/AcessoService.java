package com.example.security.service;

import com.example.security.entity.*;
import org.springframework.stereotype.Service;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.access.AccessDeniedException;

@Service
public class AcessoService {
    public User usuario() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof User user))
            throw new AuthenticationCredentialsNotFoundException("Autenticação necessária");
        return user;
    }
    public boolean admin() { return usuario().getRole() == Role.ADMIN; }
    public void proprietario(Jogador jogador) {
        if (!admin() && !jogador.getUser().getId().equals(usuario().getId()))
            throw new AccessDeniedException("Recurso de outro jogador");
    }
}
