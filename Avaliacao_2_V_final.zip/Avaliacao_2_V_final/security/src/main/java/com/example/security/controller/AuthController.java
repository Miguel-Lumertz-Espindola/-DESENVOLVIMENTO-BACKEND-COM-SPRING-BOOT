package com.example.security.controller;

import com.example.security.doc.AuthControllerDoc;
import com.example.security.dto.request.*;
import com.example.security.dto.response.*;
import com.example.security.service.AuthService;
import com.example.security.service.AcessoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.Operation;

@RestController @RequestMapping("/auth") @RequiredArgsConstructor
public class AuthController implements AuthControllerDoc {
    private final AuthService service;
    private final AcessoService acesso;
    @Override @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(service.login(request));
    }
    @Override @PostMapping("/register")
    public ResponseEntity<RegisterUserResponse> register(@Valid @RequestBody RegisterUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.register(request));
    }
    @GetMapping("/me") @SecurityRequirement(name = "bearerAuth")
    @Operation(summary = "Consulta a conta autenticada, sem senha")
    public ContaResponse me() {
        var u = acesso.usuario();
        return new ContaResponse(u.getId(), u.getName(), u.getEmail(), u.getRole());
    }
}
