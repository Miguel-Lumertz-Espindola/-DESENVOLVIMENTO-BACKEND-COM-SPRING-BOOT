package com.example.security.controller;

import com.example.security.dto.response.*;
import com.example.security.service.ProgressoService;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import java.net.URI;

@RestController @RequiredArgsConstructor
@Tag(name = "Missões e conquistas do jogador") @SecurityRequirement(name = "bearerAuth")
public class ProgressoController {
    private final ProgressoService service;
    @GetMapping("/personagens/{personagemId}/missoes") @Operation(summary = "Lista progresso nas missões")
    public List<PersonagemMissaoResponse> missoes(@PathVariable @Positive Long personagemId) { return service.listarMissoes(personagemId); }
    @PostMapping("/personagens/{personagemId}/missoes/{missaoId}") @Operation(summary = "Inicia missão com recompensa fixada neste momento")
    public ResponseEntity<PersonagemMissaoResponse> iniciar(@PathVariable @Positive Long personagemId, @PathVariable @Positive Long missaoId) {
        var result = service.iniciar(personagemId, missaoId);
        return ResponseEntity.created(URI.create("/personagens/" + personagemId + "/missoes")).body(result);
    }
    @PatchMapping("/personagens/{personagemId}/missoes/{missaoId}/concluir") @Operation(summary = "Conclui missão e entrega experiência uma única vez")
    public PersonagemMissaoResponse concluir(@PathVariable @Positive Long personagemId, @PathVariable @Positive Long missaoId) {
        return service.concluir(personagemId, missaoId);
    }
    @GetMapping("/jogadores/{jogadorId}/conquistas") @Operation(summary = "Lista conquistas recebidas")
    public List<JogadorConquistaResponse> conquistas(@PathVariable @Positive Long jogadorId) { return service.listarConquistas(jogadorId); }
    @PostMapping("/jogadores/{jogadorId}/conquistas/{conquistaId}") @Operation(summary = "Concede conquista (ADMIN)")
    public ResponseEntity<JogadorConquistaResponse> conceder(@PathVariable @Positive Long jogadorId, @PathVariable @Positive Long conquistaId) {
        var result = service.conceder(jogadorId, conquistaId);
        return ResponseEntity.created(URI.create("/jogadores/" + jogadorId + "/conquistas")).body(result);
    }
    @DeleteMapping("/jogadores/{jogadorId}/conquistas/{conquistaId}") @Operation(summary = "Revoga conquista (ADMIN)")
    public ResponseEntity<Void> revogar(@PathVariable @Positive Long jogadorId, @PathVariable @Positive Long conquistaId) {
        service.revogar(jogadorId, conquistaId); return ResponseEntity.noContent().build();
    }
}
