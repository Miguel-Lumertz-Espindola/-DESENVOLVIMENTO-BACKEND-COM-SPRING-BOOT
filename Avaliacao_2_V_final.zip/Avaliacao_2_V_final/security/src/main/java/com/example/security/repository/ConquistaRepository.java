package com.example.security.repository;

import com.example.security.entity.Conquista;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.domain.*;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.util.*;

public interface ConquistaRepository extends JpaRepository<Conquista, Long> {

}
