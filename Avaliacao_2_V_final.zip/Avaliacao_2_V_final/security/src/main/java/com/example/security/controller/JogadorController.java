package com.example.security.controller;

import com.example.security.dto.request.JogadorRequest;
import com.example.security.dto.response.*;
import com.example.security.service.JogadorService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Pageable;
import org.springdoc.core.annotations.ParameterObject;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.net.URI;

@RestController @RequestMapping("/jogadores") @RequiredArgsConstructor
@Tag(name = "Jogadores") @SecurityRequirement(name = "bearerAuth")
public class JogadorController {
    private final JogadorService service;
    @PostMapping @ApiResponse(responseCode = "201", description = "Criado") @Operation(summary = "Cria jogador")
    public ResponseEntity<JogadorResponse> criar(@Valid @RequestBody JogadorRequest request) {
        var result = service.criar(request);
        return ResponseEntity.created(URI.create("/jogadores/" + result.id())).body(result);
    }
    @GetMapping @Operation(summary = "Lista jogadores com paginação e ordenação por ID")
    public PaginaResponse<JogadorResponse> listar(@ParameterObject Pageable pagina) { return service.listar(pagina); }
    @GetMapping("/{id}") @Operation(summary = "Busca jogador por ID")
    public JogadorResponse buscar(@PathVariable @Positive Long id) { return service.buscar(id); }
    @PutMapping("/{id}") @Operation(summary = "Atualiza jogador")
    public JogadorResponse atualizar(@PathVariable @Positive Long id, @Valid @RequestBody JogadorRequest request) {
        return service.atualizar(id, request);
    }
    @DeleteMapping("/{id}") @ApiResponse(responseCode = "204", description = "Excluído") @Operation(summary = "Exclui jogador")
    public ResponseEntity<Void> excluir(@PathVariable @Positive Long id) {
        service.excluir(id); return ResponseEntity.noContent().build();
    }
}
