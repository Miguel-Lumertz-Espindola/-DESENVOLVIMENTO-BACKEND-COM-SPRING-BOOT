package com.example.security.dto.response;

public record ContaResponse(Long id, String nome, String email, com.example.security.entity.Role role) {}
