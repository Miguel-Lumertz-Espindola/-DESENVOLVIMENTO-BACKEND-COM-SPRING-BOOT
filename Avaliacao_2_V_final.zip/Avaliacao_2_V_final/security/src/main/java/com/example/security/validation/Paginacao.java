package com.example.security.validation;

import org.springframework.data.domain.*;
public final class Paginacao {
    private Paginacao() {}
    public static Pageable normalizar(Pageable pagina) {
        return PageRequest.of(pagina.getPageNumber(), Math.min(100, pagina.getPageSize()), Sort.by("id"));
    }
}
