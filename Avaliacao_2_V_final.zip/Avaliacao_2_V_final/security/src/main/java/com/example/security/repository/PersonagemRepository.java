package com.example.security.repository;

import com.example.security.entity.Personagem;
        import org.springframework.data.jpa.repository.*;
        import org.springframework.data.domain.*;
        import org.springframework.data.repository.query.Param;
        import jakarta.persistence.LockModeType;
        import java.util.*;

        public interface PersonagemRepository extends JpaRepository<Personagem, Long> {
            Page<Personagem> findByJogadorUserId(Long userId, Pageable pageable);
@Lock(LockModeType.PESSIMISTIC_WRITE)
@Query("select p from Personagem p where p.id = :id")
Optional<Personagem> findForUpdate(@Param("id") Long id);
        }
