package com.example.security.controller;

import com.example.security.dto.request.MissaoRequest;
import com.example.security.dto.response.*;
import com.example.security.service.MissaoService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Pageable;
import org.springdoc.core.annotations.ParameterObject;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.net.URI;

@RestController @RequestMapping("/missoes") @RequiredArgsConstructor
@Tag(name = "Missões") @SecurityRequirement(name = "bearerAuth")
public class MissaoController {
    private final MissaoService service;
    @PostMapping @ApiResponse(responseCode = "201", description = "Criado") @Operation(summary = "Cria missao (ADMIN)")
    public ResponseEntity<MissaoResponse> criar(@Valid @RequestBody MissaoRequest request) {
        var result = service.criar(request);
        return ResponseEntity.created(URI.create("/missoes/" + result.id())).body(result);
    }
    @GetMapping @Operation(summary = "Lista missoes com paginação e ordenação por ID")
    public PaginaResponse<MissaoResponse> listar(@ParameterObject Pageable pagina) { return service.listar(pagina); }
    @GetMapping("/{id}") @Operation(summary = "Busca missao por ID")
    public MissaoResponse buscar(@PathVariable @Positive Long id) { return service.buscar(id); }
    @PutMapping("/{id}") @Operation(summary = "Atualiza missao (ADMIN)")
    public MissaoResponse atualizar(@PathVariable @Positive Long id, @Valid @RequestBody MissaoRequest request) {
        return service.atualizar(id, request);
    }
    @DeleteMapping("/{id}") @ApiResponse(responseCode = "204", description = "Excluído") @Operation(summary = "Exclui missao (ADMIN)")
    public ResponseEntity<Void> excluir(@PathVariable @Positive Long id) {
        service.excluir(id); return ResponseEntity.noContent().build();
    }
}
