package com.example.security.doc;

import com.example.security.dto.request.*;
import com.example.security.dto.response.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
@Tag(name = "Autenticação", description = "Cadastro público cria somente JOGADOR; login retorna JWT")
public interface AuthControllerDoc {
    @Operation(summary = "Autentica com e-mail e senha")
    @ApiResponse(responseCode = "200", description = "Token gerado")
    ResponseEntity<LoginResponse> login(LoginRequest request);
    @Operation(summary = "Cadastra conta de jogador")
    @ApiResponse(responseCode = "201", description = "Conta criada")
    ResponseEntity<RegisterUserResponse> register(RegisterUserRequest request);
}
