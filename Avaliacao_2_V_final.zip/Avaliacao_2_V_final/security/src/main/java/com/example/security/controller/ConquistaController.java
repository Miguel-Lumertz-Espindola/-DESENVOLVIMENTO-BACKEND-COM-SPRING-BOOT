package com.example.security.controller;

import com.example.security.dto.request.ConquistaRequest;
import com.example.security.dto.response.*;
import com.example.security.service.ConquistaService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Pageable;
import org.springdoc.core.annotations.ParameterObject;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.net.URI;

@RestController @RequestMapping("/conquistas") @RequiredArgsConstructor
@Tag(name = "Conquistas") @SecurityRequirement(name = "bearerAuth")
public class ConquistaController {
    private final ConquistaService service;
    @PostMapping @ApiResponse(responseCode = "201", description = "Criado") @Operation(summary = "Cria conquista (ADMIN)")
    public ResponseEntity<ConquistaResponse> criar(@Valid @RequestBody ConquistaRequest request) {
        var result = service.criar(request);
        return ResponseEntity.created(URI.create("/conquistas/" + result.id())).body(result);
    }
    @GetMapping @Operation(summary = "Lista conquistas com paginação e ordenação por ID")
    public PaginaResponse<ConquistaResponse> listar(@ParameterObject Pageable pagina) { return service.listar(pagina); }
    @GetMapping("/{id}") @Operation(summary = "Busca conquista por ID")
    public ConquistaResponse buscar(@PathVariable @Positive Long id) { return service.buscar(id); }
    @PutMapping("/{id}") @Operation(summary = "Atualiza conquista (ADMIN)")
    public ConquistaResponse atualizar(@PathVariable @Positive Long id, @Valid @RequestBody ConquistaRequest request) {
        return service.atualizar(id, request);
    }
    @DeleteMapping("/{id}") @ApiResponse(responseCode = "204", description = "Excluído") @Operation(summary = "Exclui conquista (ADMIN)")
    public ResponseEntity<Void> excluir(@PathVariable @Positive Long id) {
        service.excluir(id); return ResponseEntity.noContent().build();
    }
}
