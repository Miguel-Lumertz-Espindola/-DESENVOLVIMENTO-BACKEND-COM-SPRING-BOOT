package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record PersonagemRequest(@NotBlank @Size(max = 150) String nome, @NotBlank @Size(max = 50) String classe) {}
