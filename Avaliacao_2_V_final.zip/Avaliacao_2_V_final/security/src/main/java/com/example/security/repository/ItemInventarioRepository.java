package com.example.security.repository;

import com.example.security.entity.ItemInventario;
        import org.springframework.data.jpa.repository.*;
        import org.springframework.data.domain.*;
        import org.springframework.data.repository.query.Param;
        import jakarta.persistence.LockModeType;
        import java.util.*;

        public interface ItemInventarioRepository extends JpaRepository<ItemInventario, Long> {
            List<ItemInventario> findByInventarioIdOrderByIdAsc(Long inventarioId);
Optional<ItemInventario> findByInventarioIdAndItemId(Long inventarioId, Long itemId);
long countByInventarioId(Long inventarioId);
boolean existsByItemId(Long itemId);
        }
