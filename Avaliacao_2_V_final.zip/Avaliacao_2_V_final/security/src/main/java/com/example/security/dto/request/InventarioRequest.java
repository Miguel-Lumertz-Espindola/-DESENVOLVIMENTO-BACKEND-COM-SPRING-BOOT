package com.example.security.dto.request;

import jakarta.validation.constraints.*;
public record InventarioRequest(@NotNull @Min(1) @Max(500) Integer capacidade) {}
