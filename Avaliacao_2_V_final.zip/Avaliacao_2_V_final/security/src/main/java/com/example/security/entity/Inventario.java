package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "inventarios")
        public class Inventario {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @OneToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "personagem_id", nullable = false, unique = true)
private Personagem personagem;
@Column(nullable = false) private Integer capacidade = 20;
        }
