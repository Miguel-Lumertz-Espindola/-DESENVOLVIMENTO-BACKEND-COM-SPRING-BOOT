package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "missoes")
        public class Missao {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @Column(nullable = false, length = 150) private String nome;
@Column(nullable = false, length = 1000) private String descricao;
@Column(name = "recompensa_xp", nullable = false) private Long recompensaXp;
        }
