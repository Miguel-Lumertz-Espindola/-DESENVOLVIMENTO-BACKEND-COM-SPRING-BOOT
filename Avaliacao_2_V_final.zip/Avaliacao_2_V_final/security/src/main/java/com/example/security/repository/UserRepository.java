package com.example.security.repository;

import com.example.security.entity.User;
        import org.springframework.data.jpa.repository.*;
        import org.springframework.data.domain.*;
        import org.springframework.data.repository.query.Param;
        import jakarta.persistence.LockModeType;
        import java.util.*;

        public interface UserRepository extends JpaRepository<User, Long> {
            Optional<User> findByEmailIgnoreCase(String email);
boolean existsByEmailIgnoreCase(String email);
        }
