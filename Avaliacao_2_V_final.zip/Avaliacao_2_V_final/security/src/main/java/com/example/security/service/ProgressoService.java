package com.example.security.service;

import com.example.security.entity.*;
import com.example.security.repository.*;
import com.example.security.dto.response.*;
import com.example.security.exception.NotFoundException;
import com.example.security.validation.RegrasJogo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.access.prepost.PreAuthorize;
import java.time.*;
import java.util.List;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class ProgressoService {
    private final PersonagemService personagens;
    private final JogadorService jogadores;
    private final MissaoService missoes;
    private final ConquistaService conquistas;
    private final PersonagemMissaoRepository progresso;
    private final JogadorConquistaRepository premios;
    @Transactional public PersonagemMissaoResponse iniciar(Long personagemId, Long missaoId) {
        var p = personagens.bloquear(personagemId);
        var missao = missoes.carregar(missaoId);
        RegrasJogo.exigir(progresso.findByPersonagemIdAndMissaoId(personagemId, missaoId).isEmpty(), "Missão já iniciada");
        var link = new PersonagemMissao(); link.setPersonagem(p); link.setMissao(missao);
        link.setDataInicio(hoje()); link.setRecompensaXp(missao.getRecompensaXp());
        return GameMapper.progresso(progresso.saveAndFlush(link));
    }
    @Transactional public PersonagemMissaoResponse concluir(Long personagemId, Long missaoId) {
        // Serializa conclusões e mudanças do inventário do mesmo personagem.
        var p = personagens.bloquear(personagemId);
        var link = progresso.findByPersonagemIdAndMissaoId(personagemId, missaoId)
                .orElseThrow(() -> new NotFoundException("Missão não iniciada para este personagem"));
        RegrasJogo.exigir(link.getStatus() == StatusMissao.EM_ANDAMENTO, "Missão já concluída; recompensa já entregue");
        long xp = Math.addExact(p.getExperiencia(), link.getRecompensaXp());
        RegrasJogo.exigir(xp <= 1000000000L, "Limite de experiência atingido");
        p.setExperiencia(xp); p.setNivel(RegrasJogo.nivelPara(xp));
        link.setStatus(StatusMissao.CONCLUIDA); link.setDataConclusao(hoje());
        return GameMapper.progresso(link);
    }
    public List<PersonagemMissaoResponse> listarMissoes(Long personagemId) {
        personagens.carregar(personagemId);
        return progresso.findByPersonagemIdOrderByIdAsc(personagemId).stream().map(GameMapper::progresso).toList();
    }
    public List<JogadorConquistaResponse> listarConquistas(Long jogadorId) {
        jogadores.carregar(jogadorId);
        return premios.findByJogadorIdOrderByIdAsc(jogadorId).stream().map(this::premio).toList();
    }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public JogadorConquistaResponse conceder(Long jogadorId, Long conquistaId) {
        var jogador = jogadores.carregar(jogadorId); var conquista = conquistas.carregar(conquistaId);
        RegrasJogo.exigir(!premios.existsByJogadorIdAndConquistaId(jogadorId, conquistaId), "Conquista já recebida");
        var link = new JogadorConquista(); link.setJogador(jogador); link.setConquista(conquista);
        link.setDataObtencao(hoje()); return premio(premios.saveAndFlush(link));
    }
    @Transactional @PreAuthorize("hasRole('ADMIN')")
    public void revogar(Long jogadorId, Long conquistaId) {
        jogadores.carregar(jogadorId);
        var link = premios.findByJogadorIdOrderByIdAsc(jogadorId).stream()
                .filter(p -> p.getConquista().getId().equals(conquistaId)).findFirst()
                .orElseThrow(() -> new NotFoundException("Jogador não possui esta conquista"));
        premios.delete(link);
    }
    private JogadorConquistaResponse premio(JogadorConquista p) {
        var c = p.getConquista();
        return new JogadorConquistaResponse(c.getId(), c.getNome(), c.getDescricao(), p.getDataObtencao());
    }
    private LocalDate hoje() { return LocalDate.now(ZoneId.of("America/Sao_Paulo")); }
}
