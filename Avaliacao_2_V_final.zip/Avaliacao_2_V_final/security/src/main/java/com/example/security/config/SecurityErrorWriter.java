package com.example.security.config;

import com.example.security.exception.ApiError;
import jakarta.servlet.http.*;
import tools.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.io.IOException;
@Component @RequiredArgsConstructor
public class SecurityErrorWriter {
    private final ObjectMapper mapper;
    public void write(HttpServletRequest request, HttpServletResponse response,
                      int status, String message) throws IOException {
        response.setStatus(status);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        mapper.writeValue(response.getWriter(), ApiError.of(status, message, request.getRequestURI()));
    }
}
