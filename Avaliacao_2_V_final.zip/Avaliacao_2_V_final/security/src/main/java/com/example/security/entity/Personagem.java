package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "personagens")
        public class Personagem {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "jogador_id", nullable = false)
private Jogador jogador;
@Column(nullable = false, length = 150) private String nome;
@Column(nullable = false, length = 50) private String classe;
@Column(nullable = false) private Integer nivel = 1;
@Column(nullable = false) private Long experiencia = 0L;
        }
