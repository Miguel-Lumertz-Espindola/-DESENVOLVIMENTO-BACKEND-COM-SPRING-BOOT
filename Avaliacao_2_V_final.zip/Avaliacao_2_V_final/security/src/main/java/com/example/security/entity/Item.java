package com.example.security.entity;

import jakarta.persistence.*;
        import lombok.Getter;
        import lombok.Setter;

        @Entity @Getter @Setter @Table(name = "itens")
        public class Item {
            @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            @Column(nullable = false, length = 150) private String nome;
@Column(nullable = false, length = 1000) private String descricao;
@Column(nullable = false, length = 50) private String tipo;
@Column(nullable = false, precision = 12, scale = 2)
private java.math.BigDecimal valor;
        }
