package com.example.security.dto.request;

import jakarta.validation.constraints.*;

public record RegisterUserRequest(@NotBlank @Size(max = 150) String name, @NotBlank @Email @Size(max = 250) String email, @NotBlank @Size(min = 8, max = 72) String password) {}
