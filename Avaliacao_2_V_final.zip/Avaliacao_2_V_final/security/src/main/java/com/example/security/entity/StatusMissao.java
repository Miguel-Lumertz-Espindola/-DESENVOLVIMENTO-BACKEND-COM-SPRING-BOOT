package com.example.security.entity;

public enum StatusMissao { EM_ANDAMENTO, CONCLUIDA }
