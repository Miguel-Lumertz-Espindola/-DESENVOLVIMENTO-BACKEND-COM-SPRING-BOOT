// A interface e a API usam a mesma origem. Nenhuma senha é persistida.
const key = 'guildaquest.token';
let token = sessionStorage.getItem(key) || '';
export function saveToken(value) {
  token = value || '';
  if (token) sessionStorage.setItem(key, token);
  else sessionStorage.removeItem(key);
}
export function hasToken() { return Boolean(token); }
export class ApiError extends Error {
  constructor(message, status = 0, fields = {}) { super(message); this.status = status; this.fields = fields; }
}
export async function api(path, { method = 'GET', body, authenticated = true } = {}) {
  const sentToken = authenticated ? token : '';
  const headers = { Accept: 'application/json' };
  if (sentToken) headers.Authorization = `Bearer ${sentToken}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  let response;
  try {
    response = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      cache: 'no-store', signal: AbortSignal.timeout(20000) });
  } catch (error) {
    throw new ApiError(error.name === 'TimeoutError' ? 'A resposta demorou. Atualize a lista antes de repetir a operação.' : 'Não foi possível conectar. Verifique se a aplicação está em execução.');
  }
  let data = null;
  if (response.status !== 204) {
    const text = await response.text();
    try { data = text ? JSON.parse(text) : null; } catch { /* Exibe mensagem legível se o servidor retornar HTML. */ }
  }
  if (!response.ok) {
    if (response.status === 401 && sentToken && sentToken === token) {
      saveToken(''); window.dispatchEvent(new Event('session-expired'));
    }
    const fallback = { 401: 'E-mail ou senha inválidos.', 403: 'Sua conta não tem permissão para esta ação.', 404: 'Registro não encontrado.', 409: 'A operação entra em conflito com os dados existentes.' };
    throw new ApiError(data?.message || fallback[response.status] || 'Não foi possível concluir a operação.', response.status, data?.fieldErrors || {});
  }
  return data;
}
export async function all(path) {
  const first = await api(`${path}?page=0&size=100`);
  const items = [...first.conteudo];
  for (let page = 1; page < first.totalPaginas; page++) items.push(...(await api(`${path}?page=${page}&size=100`)).conteudo);
  return items;
}
