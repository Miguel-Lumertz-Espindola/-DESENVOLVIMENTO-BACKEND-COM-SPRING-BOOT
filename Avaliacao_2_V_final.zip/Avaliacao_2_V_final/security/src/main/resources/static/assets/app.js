import { api, all, saveToken, hasToken } from './api.js';

const $ = (selector, root = document) => root.querySelector(selector);
const state = { user: null, page: 0, character: '', player: '', revision: 0, authMode: 'login' };
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const number = value => new Intl.NumberFormat('pt-BR').format(value ?? 0);
const date = value => value ? new Date(`${value}T12:00:00`).toLocaleDateString('pt-BR') : '—';
const money = value => new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value ?? 0);
const admin = () => state.user?.role === 'ADMIN';
const icons = {
  painel: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  jogadores: '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m2-16a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 4v2"/>',
  personagens: '<path d="m12 3 8 4v6c0 5-8 9-8 9S4 18 4 13V7Z"/><path d="m9 12 2 2 4-5"/>',
  itens: '<path d="m14 3 7 7-9 9-7-7Zm1 3 3 3M3 21l4-4m-4-4 8 8"/>',
  missoes: '<path d="M5 21V3m0 1c4-4 10 4 15 0v11c-5 4-11-4-15 0"/>',
  conquistas: '<path d="M8 3h8v5a4 4 0 0 1-8 0Zm8 2h4v2a5 5 0 0 1-5 5M8 5H4v2a5 5 0 0 0 5 5m3 0v6m-4 3h8m-7-3h6"/>',
  inventario: '<rect x="4" y="7" width="16" height="14" rx="2"/><path d="M8 7V5a4 4 0 0 1 8 0v2M4 12h16m-10 0v3h4v-3"/>',
  jornada: '<circle cx="5" cy="19" r="2"/><circle cx="19" cy="5" r="2"/><path d="M5 17v-4a4 4 0 0 1 4-4h6a4 4 0 0 0 4-4m-4 10h4m-2-2v4"/>',
  premiacoes: '<circle cx="12" cy="8" r="5"/><path d="m8 12-3 9 7-3 7 3-3-9"/>'
};
const icon = name => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.personagens}</svg>`;
const menu = [['painel', 'Visão geral'], ['jogadores', 'Jogadores'], ['personagens', 'Personagens'], ['itens', 'Itens'], ['missoes', 'Missões'], ['conquistas', 'Conquistas'], ['inventario', 'Inventário'], ['jornada', 'Minha jornada'], ['premiacoes', 'Conquistas recebidas']];
const nameField = { name: 'nome', label: 'Nome', max: 150 };
const descriptionField = { name: 'descricao', label: 'Descrição', type: 'textarea', max: 1000 };
const resources = {
  jogadores: { title: 'Jogadores', single: 'jogador', subtitle: 'As pessoas por trás de cada aventura.', fields: [nameField] },
  personagens: { title: 'Personagens', single: 'personagem', subtitle: 'Cada personagem, uma nova história para construir.', fields: [nameField, { name: 'classe', label: 'Classe', max: 50, placeholder: 'Ex.: Mago, Guerreiro, Arqueiro' }] },
  itens: { title: 'Itens', single: 'item', subtitle: 'O equipamento certo para o próximo desafio.', catalog: true, fields: [nameField, descriptionField, { name: 'tipo', label: 'Tipo', max: 50, placeholder: 'Ex.: ARMA, POÇÃO, ARMADURA' }, { name: 'valor', label: 'Valor (moedas)', type: 'number', min: 0, max: 9999999999.99, step: '0.01' }] },
  missoes: { title: 'Missões', single: 'missão', subtitle: 'Novos objetivos para levar seus personagens mais longe.', catalog: true, fields: [nameField, descriptionField, { name: 'recompensaXp', label: 'Recompensa de experiência (XP)', type: 'number', min: 0, max: 1000000 }] },
  conquistas: { title: 'Conquistas', single: 'conquista', subtitle: 'Reconhecimentos para momentos que merecem ficar.', catalog: true, fields: [nameField, descriptionField] }
};

function message(error) {
  const fields = Object.entries(error.fields || {}).map(([key, value]) => `${({ nome: 'Nome', descricao: 'Descrição', classe: 'Classe', valor: 'Valor', recompensaXp: 'Recompensa', password: 'Senha', email: 'E-mail', name: 'Nome', quantidade: 'Quantidade', capacidade: 'Capacidade' })[key] || key}: ${value}`);
  return [error.message, ...fields].join('\n');
}
function notify(text, error = false) {
  const item = document.createElement('div'); item.className = `toast${error ? ' error' : ''}`;
  const copy = document.createElement('span'); copy.textContent = text; item.append(copy);
  const close = document.createElement('button'); close.textContent = '×'; close.setAttribute('aria-label', 'Fechar mensagem'); close.onclick = () => item.remove(); item.append(close);
  $('#notifications').append(item); setTimeout(() => item.remove(), error ? 16000 : 6500);
}
function showError(id, error) { const element = $(id); element.textContent = message(error); element.hidden = false; }
function logout(expired = false) {
  state.revision++; state.user = null; state.character = ''; state.player = ''; saveToken('');
  document.querySelectorAll('dialog[open]').forEach(dialog => dialog.close());
  $('#workspace').replaceChildren(); $('#app-shell').hidden = true; $('#auth-screen').hidden = false;
  $('#auth-form').elements.password.value = ''; document.title = 'GuildaQuest · Entrar';
  if (expired) notify('Sua sessão expirou. Entre novamente para continuar.', true);
}
window.addEventListener('session-expired', () => logout(true));
$('#logout').addEventListener('click', () => logout());
function authMode(mode) {
  state.authMode = mode; const register = mode === 'register'; const form = $('#auth-form');
  $('#name-label').hidden = !register; form.elements.name.disabled = !register; form.elements.name.required = register;
  form.elements.password.minLength = register ? 8 : 1; form.elements.password.autocomplete = register ? 'new-password' : 'current-password';
  $('#password-help').hidden = !register; $('#auth-message').hidden = true;
  $('#auth-title').textContent = register ? 'Comece a sua história.' : 'Sua aventura continua aqui.';
  $('#auth-description').textContent = register ? 'Crie sua conta e encontre seu lugar na guilda.' : 'Entre na sua conta para acessar seus personagens.';
  $('#auth-submit').textContent = register ? 'Criar minha conta →' : 'Entrar na guilda →';
  for (const type of ['login', 'register']) { const tab = $(`#${type}-tab`); tab.classList.toggle('active', type === mode); tab.setAttribute('aria-pressed', String(type === mode)); }
}
$('#login-tab').onclick = () => authMode('login'); $('#register-tab').onclick = () => authMode('register');
$('#show-password').onclick = () => {
  const input = $('#auth-form').elements.password; const visible = input.type === 'password'; input.type = visible ? 'text' : 'password';
  $('#show-password').textContent = visible ? 'Ocultar' : 'Mostrar'; $('#show-password').setAttribute('aria-label', visible ? 'Ocultar senha' : 'Mostrar senha'); $('#show-password').setAttribute('aria-pressed', String(visible));
};
$('#auth-form').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget; const register = state.authMode === 'register';
  const data = { email: form.elements.email.value.trim(), password: form.elements.password.value };
  $('#auth-message').hidden = true; $('#auth-message').classList.remove('success');
  if (register && new TextEncoder().encode(data.password).length > 72) { showError('#auth-message', new Error('A senha deve ter no máximo 72 bytes. Acentos podem ocupar mais de um byte.')); return; }
  if (register) data.name = form.elements.name.value.trim();
  const buttons = [$('#auth-submit'), $('#login-tab'), $('#register-tab')]; buttons.forEach(button => button.disabled = true);
  try {
    const result = await api(register ? '/auth/register' : '/auth/login', { method: 'POST', body: data, authenticated: false });
    form.elements.password.value = '';
    if (register) {
      authMode('login'); $('#auth-message').classList.add('success'); $('#auth-message').textContent = 'Conta criada! Entre com o e-mail e a senha que você cadastrou.'; $('#auth-message').hidden = false; form.elements.password.focus();
    } else {
      saveToken(result.token); state.user = await api('/auth/me'); state.page = 0; startShell();
    }
  } catch (error) { showError('#auth-message', error); }
  finally { buttons.forEach(button => button.disabled = false); }
});

function startShell() {
  $('#auth-screen').hidden = true; $('#app-shell').hidden = false;
  $('#account-name').textContent = state.user.nome; $('#account-name').title = state.user.email;
  $('#account-avatar').textContent = state.user.nome.slice(0, 2).toUpperCase(); $('#account-role').textContent = admin() ? 'Administrador' : 'Jogador';
  $('#navigation').innerHTML = menu.map(([key, label]) => `<a href="#${key}">${icon(key)}<span>${label}</span></a>`).join('');
  render();
}
const currentRoute = () => location.hash.slice(1) || 'painel';
function heading(title, subtitle, action = '') { return `<div class="page-heading"><div><span class="eyebrow">SUA GUILDA, SEU UNIVERSO</span><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></div>${action}</div>`; }
function empty(title, description, action = '', kind = 'personagens') { return `<div class="empty">${icon(kind)}<h2>${esc(title)}</h2><p>${esc(description)}</p>${action}</div>`; }
function option(items, selected, label = item => item.nome) { return items.map(item => `<option value="${item.id}"${String(item.id) === String(selected) ? ' selected' : ''}>${esc(label(item))}</option>`).join(''); }
function selection(items, selected, label, type) { return `<div class="selection-row"><label>${esc(label)}<select data-select="${type}">${option(items, selected, item => `${item.nome}${item.classe ? ` · ${item.classe}` : ''} (#${item.id})`)}</select></label></div>`; }
function chosen(items, key) { const match = items.find(item => String(item.id) === String(state[key])) || items[0]; state[key] = match ? String(match.id) : ''; return match; }
function actions(id, editable = true) { return `<div class="actions"><button data-action="details" data-id="${id}">Ver</button>${editable ? `<button data-action="edit" data-id="${id}">Editar</button><button class="delete" data-action="delete" data-id="${id}">Excluir</button>` : ''}</div>`; }

async function dashboard() {
  const [players, characters, missions, items, achievements] = await Promise.all([api('/jogadores?size=1'), api('/personagens?size=4'), api('/missoes?size=1'), api('/itens?size=1'), api('/conquistas?size=1')]);
  const stats = [['personagens', 'Personagens', characters.totalElementos], ['itens', 'Itens no catálogo', items.totalElementos], ['missoes', 'Missões disponíveis', missions.totalElementos], ['conquistas', 'Conquistas no catálogo', achievements.totalElementos]];
  return heading(`Olá, ${state.user.nome.split(' ')[0]}.`, 'Uma nova aventura espera por você.') +
    `<section class="hero"><div><span class="eyebrow">SEU PRÓXIMO CAPÍTULO</span><h2>Grandes histórias são feitas<br>de pequenas conquistas.</h2><p>Escolha seu personagem, prepare o inventário e descubra o que a sua próxima missão reserva.</p><a href="#${characters.totalElementos ? 'jornada' : 'personagens'}" class="button">${characters.totalElementos ? 'Explorar minha jornada' : 'Criar meu personagem'} <span aria-hidden="true">→</span></a></div><div class="hero-emblem" aria-hidden="true"><img src="/favicon.svg" alt=""></div></section>` +
    `<div class="stats">${stats.map(([key, label, total]) => `<div class="stat"><span class="stat-label">${icon(key)}${label}</span><strong>${number(total)}</strong><small>${key === 'personagens' ? admin() ? 'Na sua guilda' : 'Na sua conta' : 'Para explorar na guilda'}</small></div>`).join('')}</div>` +
    `<div class="grid-two"><section class="panel"><div class="panel-head"><h2>${admin() ? 'Personagens da guilda' : 'Seus personagens'}</h2><a class="button secondary small" href="#personagens">Ver todos →</a></div><div class="panel-body">${characters.conteudo.length ? `<div class="character-list">${characters.conteudo.map(character => `<div class="character-card"><span class="class-icon">${icon('personagens')}</span><div><strong>${esc(character.nome)}</strong><small>${esc(character.classe)} · ${number(character.experiencia)} XP</small></div><span class="badge">Nível ${number(character.nivel)}</span></div>`).join('')}</div>` : empty('Seu primeiro personagem espera por você', 'Crie um perfil de jogador e dê início à sua jornada.', '<a class="button secondary small" href="#jogadores">Criar meu perfil</a>')}</div></section>` +
    `<section class="panel"><div class="panel-head"><h2>Seu mapa para começar</h2></div><div class="panel-body"><div class="step"><span class="step-number">01</span><div><strong>Encontre seu lugar</strong><p><a href="#jogadores">Crie seu perfil</a> e escolha um nome para a guilda.</p></div></div><div class="step"><span class="step-number">02</span><div><strong>Dê vida ao personagem</strong><p>Defina nome e classe em <a href="#personagens">Personagens</a>. O inventário nasce com ele.</p></div></div><div class="step"><span class="step-number">03</span><div><strong>Transforme desafios em experiência</strong><p><a href="#jornada">Inicie uma missão</a>, conclua e acompanhe a evolução.</p></div></div></div></section></div>` +
    (admin() ? '<div class="notice">Você está como administrador: gerencie os catálogos e conceda conquistas. Novos perfis e personagens são criados para a própria conta.</div>' : players.totalElementos ? '' : '<div class="notice">Primeiro acesso? Crie seu perfil em Jogadores antes de cadastrar um personagem.</div>');
}

async function listResource(route) {
  const config = resources[route]; const data = await api(`/${route}?page=${state.page}&size=10`);
  if (state.page > 0 && !data.conteudo.length) { state.page = Math.max(0, data.totalPaginas - 1); return listResource(route); }
  const writable = !config.catalog || admin(); let canCreate = writable;
  if (route === 'jogadores') { const players = admin() ? await all('/jogadores') : data.conteudo; canCreate = !players.some(player => player.userId === state.user.id); }
  const createLabel = route === 'jogadores' ? 'Criar meu perfil' : `Cadastrar ${config.single}`;
  const action = canCreate ? `<button class="button primary" data-action="create">+ ${createLabel}</button>` : '';
  let extraHeads = '', cell;
  if (route === 'jogadores') { extraHeads = '<th>Conta</th>'; cell = row => `<td>#${row.userId}</td>`; }
  if (route === 'personagens') { extraHeads = '<th>Classe</th><th>Nível / XP</th><th>Jogador</th>'; cell = row => `<td>${esc(row.classe)}</td><td><span class="badge">Nível ${row.nivel}</span><div class="description">${number(row.experiencia)} XP</div></td><td>#${row.jogadorId}</td>`; }
  if (route === 'itens') { extraHeads = '<th>Tipo</th><th>Valor</th>'; cell = row => `<td><span class="badge">${esc(row.tipo)}</span></td><td>${money(row.valor)} moedas</td>`; }
  if (route === 'missoes') { extraHeads = '<th>Recompensa</th>'; cell = row => `<td><span class="badge">${number(row.recompensaXp)} XP</span></td>`; }
  if (route === 'conquistas') cell = () => '';
  const rows = data.conteudo.map(row => `<tr data-filter="${esc(`${row.nome} ${row.descricao || ''} ${row.classe || ''} ${row.tipo || ''}`.toLocaleLowerCase('pt-BR'))}"><td><strong>${esc(row.nome)}</strong>${row.descricao ? `<div class="description">${esc(row.descricao)}</div>` : ''}<div class="description">#${row.id}</div></td>${cell(row)}<td>${actions(row.id, writable)}</td></tr>`).join('');
  return heading(config.title, config.subtitle, action) +
    (!writable ? '<div class="notice">Você pode consultar este catálogo. Criação, edição e exclusão estão disponíveis para administradores.</div>' : '') +
    (route === 'jogadores' ? '<div class="notice">Cada conta possui um perfil de jogador. Ao criar um perfil, ele será vinculado à sua conta.</div>' : '') +
    `<section class="panel"><div class="toolbar"><input class="search" id="list-search" type="search" placeholder="Filtrar nomes nesta página..." aria-label="Filtrar registros nesta página"><small>${number(data.totalElementos)} registro(s) · ${writable ? 'Gerencie seus registros' : 'Catálogo da guilda'}</small></div>${rows ? `<div class="table-wrap"><table><thead><tr><th>Nome</th>${extraHeads}<th><span class="sr-only">Ações</span></th></tr></thead><tbody>${rows}</tbody></table></div><div id="filter-empty" hidden>${empty('Nenhum resultado nesta página', 'Tente outro termo ou navegue para a próxima página.')}</div>` : empty(`Nenhum registro por aqui`, canCreate ? `Use o botão acima para cadastrar seu primeiro ${config.single}.` : 'Os registros aparecerão aqui quando forem cadastrados.', '', route)}<div class="pagination"><span>Página ${data.totalPaginas ? data.pagina + 1 : 1} de ${Math.max(1, data.totalPaginas)}</span><div><button class="button secondary small" data-action="previous"${data.pagina === 0 ? ' disabled' : ''}>← Anterior</button><button class="button secondary small" data-action="next"${data.pagina + 1 >= data.totalPaginas ? ' disabled' : ''}>Próxima →</button></div></div></section>`;
}

async function inventory() {
  const characters = await all('/personagens'); const character = chosen(characters, 'character');
  const title = heading('Inventário', 'Prepare seus personagens para o que vem a seguir.');
  if (!character) return title + empty('Crie um personagem primeiro', 'Todo personagem recebe um inventário de 20 espaços.', '<a class="button primary" href="#personagens">Ir para personagens</a>', 'inventario');
  const [bag, items] = await Promise.all([api(`/personagens/${character.id}/inventario`), all('/itens')]);
  return title + selection(characters, character.id, 'Personagem', 'character') +
    `<section class="panel"><div class="panel-head"><div><h2>Inventário de ${esc(character.nome)}</h2><p>Um espaço por tipo de item. Itens iguais compartilham o espaço.</p></div><button class="button secondary small" data-action="capacity" data-value="${bag.capacidade}">Alterar capacidade</button></div><div class="panel-body inventory-summary"><strong>${bag.itens.length} / ${bag.capacidade}</strong><span>espaços ocupados</span></div>${bag.itens.length ? `<div class="table-wrap"><table><thead><tr><th>Item</th><th>Quantidade</th><th><span class="sr-only">Ações</span></th></tr></thead><tbody>${bag.itens.map(item => `<tr><td><strong>${esc(item.nome)}</strong></td><td>${number(item.quantidade)}</td><td><div class="actions"><button data-action="quantity" data-id="${item.itemId}" data-value="${item.quantidade}">Alterar quantidade</button><button class="delete" data-action="remove-item" data-id="${item.itemId}" data-name="${esc(item.nome)}">Remover</button></div></td></tr>`).join('')}</tbody></table></div>` : empty('Sua mochila está vazia', 'Adicione um item do catálogo para preparar este personagem.', '', 'inventario')}</section>` +
    `<section class="panel"><div class="panel-head"><h2>Adicionar ao inventário</h2></div><div class="panel-body">${items.length ? `<form id="add-item-form" class="inline-form"><label>Item<select name="itemId" required>${option(items)}</select></label><label class="quantity">Quantidade<input name="quantidade" type="number" min="1" max="1000000" step="1" value="1" required></label><button class="button primary" type="submit">Adicionar item</button></form>` : '<p class="muted">O catálogo ainda não tem itens. Um administrador precisa cadastrá-los em Itens.</p>'}</div></section>`;
}

async function journey() {
  const characters = await all('/personagens'); const character = chosen(characters, 'character');
  const title = heading('Minha jornada', 'Novas missões, mais experiência e histórias para contar.');
  if (!character) return title + empty('Sua jornada começa com um personagem', 'Crie um personagem para acessar as missões.', '<a class="button primary" href="#personagens">Ir para personagens</a>', 'jornada');
  const [progress, catalog] = await Promise.all([api(`/personagens/${character.id}/missoes`), all('/missoes')]);
  const available = catalog.filter(mission => !progress.some(current => current.missaoId === mission.id));
  return title + selection(characters, character.id, 'Personagem', 'character') +
    `<div class="notice"><strong>${esc(character.nome)}</strong> · Nível ${character.nivel} · ${number(character.experiencia)} XP. A cada 100 XP, um novo nível. Cada missão entrega sua recompensa uma única vez.</div>` +
    `<section class="panel"><div class="panel-head"><h2>Missões do personagem</h2><span class="badge">${progress.length} iniciada(s)</span></div><div class="panel-body">${progress.length ? `<div class="quest-list">${progress.map(mission => `<article class="quest-card"><div><h3>${esc(mission.nome)}</h3><div class="quest-meta"><span class="badge ${mission.status === 'CONCLUIDA' ? 'done' : 'progress'}">${mission.status === 'CONCLUIDA' ? 'Concluída' : 'Em andamento'}</span><small>${number(mission.recompensaXp)} XP · Início: ${date(mission.dataInicio)}${mission.dataConclusao ? ` · Conclusão: ${date(mission.dataConclusao)}` : ''}</small></div></div>${mission.status === 'EM_ANDAMENTO' ? `<button class="button primary small" data-action="finish-mission" data-id="${mission.missaoId}" data-name="${esc(mission.nome)}" data-xp="${mission.recompensaXp}">Concluir missão</button>` : ''}</article>`).join('')}</div>` : empty('O primeiro desafio espera por você', 'Escolha uma missão disponível abaixo e comece a explorar.', '', 'missoes')}</div></section>` +
    `<section class="panel"><div class="panel-head"><h2>Disponíveis para começar</h2><span class="badge">${available.length} disponível(is)</span></div><div class="panel-body">${available.length ? `<div class="quest-list">${available.map(mission => `<article class="quest-card"><div><h3>${esc(mission.nome)}</h3><p>${esc(mission.descricao)}</p><span class="badge">${number(mission.recompensaXp)} XP</span></div><button class="button secondary small" data-action="start-mission" data-id="${mission.id}">Iniciar missão →</button></article>`).join('')}</div>` : empty('Nenhuma nova missão disponível', catalog.length ? 'Você já iniciou todas as missões do catálogo.' : 'Um administrador pode cadastrar novos desafios em Missões.', '', 'missoes')}</div></section>`;
}

async function awards() {
  const players = await all('/jogadores'); const player = chosen(players, 'player');
  const title = heading('Conquistas recebidas', 'Marcos que fazem parte da história de cada jogador.');
  if (!player) return title + empty('Crie seu perfil de jogador', 'As conquistas ficam vinculadas ao perfil do jogador.', '<a class="button primary" href="#jogadores">Ir para jogadores</a>', 'conquistas');
  const received = await api(`/jogadores/${player.id}/conquistas`); const catalog = admin() ? await all('/conquistas') : [];
  const available = catalog.filter(item => !received.some(award => award.conquistaId === item.id));
  return title + selection(players, player.id, 'Jogador', 'player') +
    (!admin() ? '<div class="notice">As conquistas são concedidas pela administração da guilda. Aqui você acompanha os reconhecimentos recebidos.</div>' : '') +
    `<section class="panel"><div class="panel-head"><h2>Conquistas de ${esc(player.nome)}</h2><span class="badge">${received.length} recebida(s)</span></div><div class="panel-body">${received.length ? `<div class="quest-list">${received.map(award => `<article class="quest-card"><div><h3>${icon('conquistas')} ${esc(award.nome)}</h3><p>${esc(award.descricao)}</p><small>Recebida em ${date(award.dataObtencao)}</small></div>${admin() ? `<button class="button secondary small" data-action="revoke-award" data-id="${award.conquistaId}" data-name="${esc(award.nome)}">Revogar</button>` : ''}</article>`).join('')}</div>` : empty('Novas conquistas virão', 'Os reconhecimentos concedidos a este jogador aparecerão aqui.', '', 'conquistas')}</div></section>` +
    (admin() ? `<section class="panel"><div class="panel-head"><h2>Conceder uma conquista</h2></div><div class="panel-body">${available.length ? `<form id="grant-award-form" class="inline-form"><label>Conquista<select name="conquistaId" required>${option(available)}</select></label><button class="button primary" type="submit">Conceder conquista</button></form>` : '<p class="muted">Não há conquistas disponíveis para conceder. Cadastre novas conquistas ou selecione outro jogador.</p>'}</div></section>` : '');
}

async function render() {
  if (!state.user) return;
  const revision = ++state.revision; let route = currentRoute(); if (!menu.some(([key]) => key === route)) route = 'painel';
  const label = menu.find(([key]) => key === route)[1]; document.title = `${label} · GuildaQuest`;
  $('#navigation').querySelectorAll('a').forEach(link => { if (link.hash === `#${route}`) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current'); });
  const workspace = $('#workspace'); workspace.setAttribute('aria-busy', 'true'); workspace.innerHTML = '<div class="loading" role="status">Preparando sua guilda...</div>';
  try {
    const html = resources[route] ? await listResource(route) : route === 'inventario' ? await inventory() : route === 'jornada' ? await journey() : route === 'premiacoes' ? await awards() : await dashboard();
    if (revision !== state.revision || !state.user) return;
    workspace.innerHTML = html;
    const search = $('#list-search'); if (search) search.addEventListener('input', () => {
      let visible = 0; const query = search.value.trim().toLocaleLowerCase('pt-BR');
      workspace.querySelectorAll('tr[data-filter]').forEach(row => { row.hidden = !row.dataset.filter.includes(query); if (!row.hidden) visible++; });
      const noResults = $('#filter-empty'); if (noResults) noResults.hidden = visible > 0;
    });
  } catch (error) {
    if (revision === state.revision && state.user) workspace.innerHTML = heading('Não foi possível carregar', 'Verifique a conexão e tente novamente.') + `<div class="notice">${esc(message(error))}</div><button class="button secondary" data-action="reload">Tentar novamente</button>`;
  } finally { if (revision === state.revision) workspace.removeAttribute('aria-busy'); }
}
window.addEventListener('hashchange', () => { state.page = 0; render(); });
$('#workspace').addEventListener('change', event => { const type = event.target.dataset.select; if (type) { state[type] = event.target.value; render(); } });

document.querySelectorAll('dialog').forEach(dialog => {
  dialog.querySelectorAll('[data-close]').forEach(button => button.onclick = () => dialog.close());
  dialog.addEventListener('cancel', event => { if (dialog.dataset.busy === 'true') event.preventDefault(); });
});
function fieldHTML(field, value) {
  const id = `field-${field.name}`; const attrs = `id="${id}" name="${field.name}" required${field.max !== undefined ? ` ${field.type === 'number' ? 'max' : 'maxlength'}="${field.max}"` : ''}${field.min !== undefined ? ` min="${field.min}"` : ''}`;
  return `<label for="${id}">${esc(field.label)}${field.type === 'textarea' ? `<textarea ${attrs}>${esc(value)}</textarea>` : `<input ${attrs} type="${field.type || 'text'}" value="${esc(value)}"${field.type === 'number' ? ` step="${field.step || '1'}"` : ''}${field.placeholder ? ` placeholder="${esc(field.placeholder)}"` : ''}>`}</label>`;
}
function modalBusy(dialog, busy) {
  dialog.dataset.busy = String(busy); dialog.querySelectorAll('button,input,select,textarea').forEach(element => element.disabled = busy);
}
function editForm(title, fields, values, save, note = '') {
  const dialog = $('#editor'); $('#editor-title').textContent = title; $('#editor-note').textContent = note;
  $('#editor-fields').innerHTML = fields.map(field => fieldHTML(field, values[field.name] ?? '')).join('');
  $('#editor-error').hidden = true; $('#editor-save').hidden = false; $('#editor-save').textContent = 'Salvar';
  modalBusy(dialog, false);
  $('#editor-form').onsubmit = async event => {
    event.preventDefault(); if (dialog.dataset.busy === 'true') return;
    const data = Object.fromEntries(fields.map(field => [field.name, field.type === 'number' ? Number(event.currentTarget.elements[field.name].value) : event.currentTarget.elements[field.name].value.trim()]));
    modalBusy(dialog, true); $('#editor-error').hidden = true;
    try { await save(data); dialog.close(); notify('Alteração salva com sucesso.'); await render(); }
    catch (error) { if (dialog.open) showError('#editor-error', error); }
    finally { modalBusy(dialog, false); }
  };
  dialog.showModal();
}
function confirm(title, description, action, { text = 'Confirmar', danger = true } = {}) {
  const dialog = $('#confirmation'); $('#confirm-title').textContent = title; $('#confirm-description').textContent = description; $('#confirm-error').hidden = true;
  const accept = $('#confirm-accept'); accept.textContent = text; accept.className = `button ${danger ? 'danger' : 'primary'}`; modalBusy(dialog, false);
  accept.onclick = async () => {
    if (dialog.dataset.busy === 'true') return; modalBusy(dialog, true); $('#confirm-error').hidden = true;
    try { await action(); dialog.close(); notify('Operação concluída com sucesso.'); await render(); }
    catch (error) { if (dialog.open) showError('#confirm-error', error); }
    finally { modalBusy(dialog, false); }
  };
  dialog.showModal();
}

$('#workspace').addEventListener('click', async event => {
  const button = event.target.closest('button[data-action]'); if (!button || button.disabled) return;
  const action = button.dataset.action; const route = currentRoute(); const id = button.dataset.id; const config = resources[route];
  if (action === 'previous' || action === 'next') { state.page += action === 'next' ? 1 : -1; render(); return; }
  if (action === 'reload') { render(); return; }
  button.disabled = true;
  try {
    if (action === 'create' || action === 'edit') {
      const values = action === 'edit' ? await api(`/${route}/${id}`) : {};
      editForm(`${action === 'edit' ? 'Editar' : 'Cadastrar'} ${config.single}`, config.fields, values,
        data => api(`/${route}${action === 'edit' ? `/${id}` : ''}`, { method: action === 'edit' ? 'PUT' : 'POST', body: data }),
        route === 'personagens' ? 'Novos personagens pertencem ao seu perfil. Nível e experiência evoluem pelas missões.' : route === 'jogadores' ? 'O novo perfil será vinculado à conta que está conectada.' : 'Preencha os campos para salvar no catálogo.');
    }
    if (action === 'details') {
      const row = await api(`/${route}/${id}`); const dialog = $('#editor'); $('#editor-title').textContent = row.nome; $('#editor-note').textContent = `Detalhes do registro #${row.id}`;
      const fields = [{ name: 'id', label: 'ID' }, ...config.fields, ...(route === 'personagens' ? [{ name: 'jogadorId', label: 'Jogador (ID)' }, { name: 'nivel', label: 'Nível' }, { name: 'experiencia', label: 'Experiência (XP)' }] : route === 'jogadores' ? [{ name: 'userId', label: 'Conta (ID)' }] : [])];
      $('#editor-fields').innerHTML = `<dl>${fields.map(field => `<dt>${esc(field.label)}</dt><dd>${esc(row[field.name])}</dd>`).join('')}</dl>`; $('#editor-error').hidden = true; $('#editor-save').hidden = true; $('#editor-form').onsubmit = event => event.preventDefault(); modalBusy(dialog, false); dialog.showModal();
    }
    if (action === 'delete') {
      const row = await api(`/${route}/${id}`);
      confirm(`Excluir ${config.single}?`, `Deseja excluir “${row.nome}”? ${route === 'jogadores' ? 'Os personagens, inventários e o progresso deste perfil também serão excluídos. A conta de acesso será preservada.' : route === 'personagens' ? 'O inventário e o progresso deste personagem também serão excluídos.' : 'Registros vinculados ao jogo precisam ser desvinculados antes da exclusão.'}`, () => api(`/${route}/${id}`, { method: 'DELETE' }), { text: 'Excluir' });
    }
    if (action === 'capacity') editForm('Alterar capacidade', [{ name: 'capacidade', label: 'Quantidade de espaços', type: 'number', min: 1, max: 500 }], { capacidade: button.dataset.value }, data => api(`/personagens/${state.character}/inventario`, { method: 'PUT', body: data }), 'A capacidade não pode ficar abaixo dos itens distintos já armazenados.');
    if (action === 'quantity') editForm('Alterar quantidade', [{ name: 'quantidade', label: 'Quantidade', type: 'number', min: 1, max: 1000000 }], { quantidade: button.dataset.value }, data => api(`/personagens/${state.character}/inventario/itens/${id}`, { method: 'PUT', body: data }));
    if (action === 'remove-item') confirm('Remover item?', `Remover todas as unidades de “${button.dataset.name}” deste inventário?`, () => api(`/personagens/${state.character}/inventario/itens/${id}`, { method: 'DELETE' }), { text: 'Remover' });
    if (action === 'start-mission') { await api(`/personagens/${state.character}/missoes/${id}`, { method: 'POST' }); notify('Missão iniciada. Boa jornada!'); await render(); }
    if (action === 'finish-mission') confirm('Concluir missão?', `Concluir “${button.dataset.name}” e receber ${number(button.dataset.xp)} XP? A recompensa é concedida uma única vez.`, () => api(`/personagens/${state.character}/missoes/${id}/concluir`, { method: 'PATCH' }), { text: 'Concluir e receber XP', danger: false });
    if (action === 'revoke-award') confirm('Revogar conquista?', `Remover a conquista “${button.dataset.name}” deste jogador?`, () => api(`/jogadores/${state.player}/conquistas/${id}`, { method: 'DELETE' }), { text: 'Revogar' });
  } catch (error) { if (state.user) notify(message(error), true); }
  finally { button.disabled = false; }
});
$('#workspace').addEventListener('submit', async event => {
  const form = event.target; if (!['add-item-form', 'grant-award-form'].includes(form.id)) return;
  event.preventDefault(); const submit = $('button[type=submit]', form); if (submit.disabled) return; submit.disabled = true;
  try {
    if (form.id === 'add-item-form') await api(`/personagens/${state.character}/inventario/itens`, { method: 'POST', body: { itemId: Number(form.elements.itemId.value), quantidade: Number(form.elements.quantidade.value) } });
    else await api(`/jogadores/${state.player}/conquistas/${Number(form.elements.conquistaId.value)}`, { method: 'POST' });
    notify(form.id === 'add-item-form' ? 'Item adicionado ao inventário.' : 'Conquista concedida.'); await render();
  } catch (error) { if (state.user) notify(message(error), true); }
  finally { submit.disabled = false; }
});

authMode('login');
if (hasToken()) {
  $('#auth-submit').disabled = true;
  try { state.user = await api('/auth/me'); startShell(); }
  catch (error) { if (error.status !== 401) showError('#auth-message', error); }
  finally { $('#auth-submit').disabled = false; }
}
