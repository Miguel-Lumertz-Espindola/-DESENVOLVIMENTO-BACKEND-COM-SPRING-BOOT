-- V1 a V10 são preservadas, inclusive seus checksums.
-- As tabelas antigas não possuem FKs/proprietários: conservar seus registros,
-- sem atribuir inventários, missões ou conquistas arbitrariamente a uma conta.
ALTER TABLE jogador RENAME TO jogador_legado;
ALTER TABLE personagen RENAME TO personagen_legado;
ALTER TABLE inventario RENAME TO inventario_legado;
ALTER TABLE iteminventario RENAME TO iteminventario_legado;
ALTER TABLE item RENAME TO item_legado;
ALTER TABLE personagemmissao RENAME TO personagemmissao_legado;
ALTER TABLE missao RENAME TO missao_legado;
ALTER TABLE jogadorconquista RENAME TO jogadorconquista_legado;
ALTER TABLE conquista RENAME TO conquista_legado;

-- Contas e hashes existentes continuam na mesma tabela.
UPDATE users SET email = lower(btrim(email));
CREATE UNIQUE INDEX uq_users_email_ci ON users (lower(email));
ALTER TABLE users ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'JOGADOR';
ALTER TABLE users ADD CONSTRAINT ck_users_role CHECK (role IN ('JOGADOR', 'ADMIN'));

CREATE TABLE jogadores (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE RESTRICT,
    nome VARCHAR(150) NOT NULL CHECK (length(btrim(nome)) > 0)
);
CREATE TABLE personagens (
    id BIGSERIAL PRIMARY KEY,
    jogador_id BIGINT NOT NULL REFERENCES jogadores(id) ON DELETE CASCADE,
    nome VARCHAR(150) NOT NULL CHECK (length(btrim(nome)) > 0),
    classe VARCHAR(50) NOT NULL CHECK (length(btrim(classe)) > 0),
    nivel INTEGER NOT NULL DEFAULT 1 CHECK (nivel > 0),
    experiencia BIGINT NOT NULL DEFAULT 0 CHECK (experiencia BETWEEN 0 AND 1000000000),
    CONSTRAINT ck_personagem_nivel CHECK (nivel = 1 + experiencia / 100)
);
CREATE INDEX ix_personagens_jogador ON personagens(jogador_id);
CREATE TABLE inventarios (
    id BIGSERIAL PRIMARY KEY,
    personagem_id BIGINT NOT NULL UNIQUE REFERENCES personagens(id) ON DELETE CASCADE,
    capacidade INTEGER NOT NULL DEFAULT 20 CHECK (capacidade BETWEEN 1 AND 500)
);
CREATE TABLE itens (
    id BIGSERIAL PRIMARY KEY,
    nome VARCHAR(150) NOT NULL CHECK (length(btrim(nome)) > 0),
    descricao VARCHAR(1000) NOT NULL CHECK (length(btrim(descricao)) > 0),
    tipo VARCHAR(50) NOT NULL CHECK (length(btrim(tipo)) > 0),
    valor NUMERIC(12,2) NOT NULL CHECK (valor >= 0)
);
CREATE TABLE itens_inventario (
    id BIGSERIAL PRIMARY KEY,
    inventario_id BIGINT NOT NULL REFERENCES inventarios(id) ON DELETE CASCADE,
    item_id BIGINT NOT NULL REFERENCES itens(id) ON DELETE RESTRICT,
    quantidade INTEGER NOT NULL CHECK (quantidade BETWEEN 1 AND 1000000),
    CONSTRAINT uq_inventario_item UNIQUE (inventario_id, item_id)
);
CREATE INDEX ix_itens_inventario_item ON itens_inventario(item_id);
CREATE TABLE missoes (
    id BIGSERIAL PRIMARY KEY,
    nome VARCHAR(150) NOT NULL CHECK (length(btrim(nome)) > 0),
    descricao VARCHAR(1000) NOT NULL CHECK (length(btrim(descricao)) > 0),
    recompensa_xp BIGINT NOT NULL CHECK (recompensa_xp BETWEEN 0 AND 1000000)
);
CREATE TABLE personagens_missoes (
    id BIGSERIAL PRIMARY KEY,
    personagem_id BIGINT NOT NULL REFERENCES personagens(id) ON DELETE CASCADE,
    missao_id BIGINT NOT NULL REFERENCES missoes(id) ON DELETE RESTRICT,
    status VARCHAR(30) NOT NULL CHECK (status IN ('EM_ANDAMENTO', 'CONCLUIDA')),
    data_inicio DATE NOT NULL,
    data_conclusao DATE,
    recompensa_xp BIGINT NOT NULL CHECK (recompensa_xp BETWEEN 0 AND 1000000),
    CONSTRAINT uq_personagem_missao UNIQUE(personagem_id, missao_id),
    CONSTRAINT ck_missao_datas CHECK (
        (status = 'EM_ANDAMENTO' AND data_conclusao IS NULL) OR
        (status = 'CONCLUIDA' AND data_conclusao IS NOT NULL AND data_conclusao >= data_inicio)
    )
);
CREATE INDEX ix_personagens_missoes_missao ON personagens_missoes(missao_id);
CREATE TABLE conquistas (
    id BIGSERIAL PRIMARY KEY,
    nome VARCHAR(150) NOT NULL CHECK (length(btrim(nome)) > 0),
    descricao VARCHAR(1000) NOT NULL CHECK (length(btrim(descricao)) > 0)
);
CREATE TABLE jogadores_conquistas (
    id BIGSERIAL PRIMARY KEY,
    jogador_id BIGINT NOT NULL REFERENCES jogadores(id) ON DELETE CASCADE,
    conquista_id BIGINT NOT NULL REFERENCES conquistas(id) ON DELETE RESTRICT,
    data_obtencao DATE NOT NULL,
    CONSTRAINT uq_jogador_conquista UNIQUE(jogador_id, conquista_id)
);
CREATE INDEX ix_jogadores_conquistas_conquista ON jogadores_conquistas(conquista_id);
