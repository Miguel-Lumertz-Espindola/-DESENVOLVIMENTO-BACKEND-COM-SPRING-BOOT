# Implementação dos CRUDs e das camadas do jogo

Foram implementados os cinco CRUDs (Jogador, Personagem, Item, Missao e Conquista), nove entidades de domínio, repositories, DTOs, Services transacionais, validação e tratamento centralizado de erros.

Relacionamentos: conta/perfil 1:1, jogador/personagens 1:N, personagem/inventário 1:1 e três N:N por entidades de associação (inventário/itens, personagens/missões, jogadores/conquistas).

Autorização: proprietário dos dados ou ADMIN; catálogos modificáveis apenas por ADMIN. Cadastro público não permite promoção de perfil. JWT verifica assinatura e expiração, carrega permissões do banco e usa segredo externo.

Regras: capacidade/quantidade no inventário, XP e nível derivados, missão concluída/recompensada uma vez, snapshot da recompensa e conquista sem duplicidade. Exclusões de agregado preservam contas e catálogos; exclusão de catálogo vinculado é rejeitada.

## Validação executada

- Compilação Java 21 com Spring Boot 4.1.1: BUILD SUCCESS.
- PostgreSQL 17 temporário e isolado do banco original.
- 20 testes de integração executados: zero falhas, zero erros, zero ignorados.
- Incluídos: CRUDs, segurança, validações, FKs, cascatas, inventário, missões, conquistas, Swagger, preservação dos dados legados e duas conclusões concorrentes sem duplicar XP.
- Empacotamento Maven: BUILD SUCCESS.
- Script PowerShell de testes: sintaxe conferida.
- V1 a V10: conteúdo original preservado byte a byte.

## Migrations e dados existentes

A V11 conserva as contas existentes e preserva os registros do jogo em tabelas com sufixo `_legado`. O novo modelo possui FKs e restrições consistentes. Os registros antigos do jogo precisam de importação explícita caso existam, porque seu esquema anterior não identificava os relacionamentos e seus proprietários.

Nenhuma migration foi executada no banco original durante o desenvolvimento. A V11 será executada pelo Flyway quando a nova aplicação for iniciada nesse banco. Se houver e-mails duplicados, a criação da unicidade interrompe e reverte a migration, sem excluir uma conta arbitrariamente.

## Execução

Leia `README.md`. Configuração local privada, senhas reais, banco de testes, dependências baixadas e diretório `target` não integram o ZIP. O script de testes usa seu próprio PostgreSQL temporário. Uma conta precisa ser promovida pelo responsável pelo banco para exercer o papel ADMIN, conforme o comando documentado no README.

## Limites desta implementação

O nome GuildaQuest é provisório. A equipe ainda precisa concluir seus documentos de análise/UML, protótipos/frontend conforme orientação do professor, identificação dos integrantes/contribuições e apresentação. A implementação desta etapa é do backend.

## Arquivos novos ou alterados

- NOVO: `.gitignore`
- NOVO: `.mvn\wrapper\maven-wrapper.properties`
- NOVO: `docs\RELACIONAMENTOS.md`
- ALTERADO: `pom.xml`
- NOVO: `README.md`
- NOVO: `scripts\test.ps1`
- ALTERADO: `src\main\java\com\example\security\config\AuthConfig.java`
- ALTERADO: `src\main\java\com\example\security\config\OpenApiConfig.java`
- ALTERADO: `src\main\java\com\example\security\config\SecurityConfig.java`
- NOVO: `src\main\java\com\example\security\config\SecurityErrorWriter.java`
- ALTERADO: `src\main\java\com\example\security\config\SecurityFilter.java`
- ALTERADO: `src\main\java\com\example\security\config\TokenConfig.java`
- ALTERADO: `src\main\java\com\example\security\controller\AuthController.java`
- NOVO: `src\main\java\com\example\security\controller\ConquistaController.java`
- NOVO: `src\main\java\com\example\security\controller\InventarioController.java`
- NOVO: `src\main\java\com\example\security\controller\ItemController.java`
- NOVO: `src\main\java\com\example\security\controller\JogadorController.java`
- NOVO: `src\main\java\com\example\security\controller\MissaoController.java`
- NOVO: `src\main\java\com\example\security\controller\PersonagemController.java`
- NOVO: `src\main\java\com\example\security\controller\ProgressoController.java`
- ALTERADO: `src\main\java\com\example\security\doc\AuthControllerDoc.java`
- NOVO: `src\main\java\com\example\security\dto\request\ConquistaRequest.java`
- NOVO: `src\main\java\com\example\security\dto\request\InventarioItemRequest.java`
- NOVO: `src\main\java\com\example\security\dto\request\InventarioRequest.java`
- NOVO: `src\main\java\com\example\security\dto\request\ItemRequest.java`
- NOVO: `src\main\java\com\example\security\dto\request\JogadorRequest.java`
- ALTERADO: `src\main\java\com\example\security\dto\request\LoginRequest.java`
- NOVO: `src\main\java\com\example\security\dto\request\MissaoRequest.java`
- NOVO: `src\main\java\com\example\security\dto\request\PersonagemRequest.java`
- NOVO: `src\main\java\com\example\security\dto\request\QuantidadeRequest.java`
- ALTERADO: `src\main\java\com\example\security\dto\request\RegisterUserRequest.java`
- NOVO: `src\main\java\com\example\security\dto\response\ConquistaResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\ContaResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\InventarioItemResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\InventarioResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\ItemResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\JogadorConquistaResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\JogadorResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\MissaoResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\PaginaResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\PersonagemMissaoResponse.java`
- NOVO: `src\main\java\com\example\security\dto\response\PersonagemResponse.java`
- NOVO: `src\main\java\com\example\security\entity\Conquista.java`
- NOVO: `src\main\java\com\example\security\entity\Inventario.java`
- NOVO: `src\main\java\com\example\security\entity\Item.java`
- NOVO: `src\main\java\com\example\security\entity\ItemInventario.java`
- NOVO: `src\main\java\com\example\security\entity\Jogador.java`
- NOVO: `src\main\java\com\example\security\entity\JogadorConquista.java`
- NOVO: `src\main\java\com\example\security\entity\Missao.java`
- NOVO: `src\main\java\com\example\security\entity\Personagem.java`
- NOVO: `src\main\java\com\example\security\entity\PersonagemMissao.java`
- NOVO: `src\main\java\com\example\security\entity\Role.java`
- NOVO: `src\main\java\com\example\security\entity\StatusMissao.java`
- ALTERADO: `src\main\java\com\example\security\entity\User.java`
- NOVO: `src\main\java\com\example\security\exception\ApiError.java`
- NOVO: `src\main\java\com\example\security\exception\BusinessException.java`
- NOVO: `src\main\java\com\example\security\exception\GlobalExceptionHandler.java`
- NOVO: `src\main\java\com\example\security\exception\NotFoundException.java`
- NOVO: `src\main\java\com\example\security\repository\ConquistaRepository.java`
- NOVO: `src\main\java\com\example\security\repository\InventarioRepository.java`
- NOVO: `src\main\java\com\example\security\repository\ItemInventarioRepository.java`
- NOVO: `src\main\java\com\example\security\repository\ItemRepository.java`
- NOVO: `src\main\java\com\example\security\repository\JogadorConquistaRepository.java`
- NOVO: `src\main\java\com\example\security\repository\JogadorRepository.java`
- NOVO: `src\main\java\com\example\security\repository\MissaoRepository.java`
- NOVO: `src\main\java\com\example\security\repository\PersonagemMissaoRepository.java`
- NOVO: `src\main\java\com\example\security\repository\PersonagemRepository.java`
- ALTERADO: `src\main\java\com\example\security\repository\UserRepository.java`
- NOVO: `src\main\java\com\example\security\service\AcessoService.java`
- NOVO: `src\main\java\com\example\security\service\AuthService.java`
- NOVO: `src\main\java\com\example\security\service\ConquistaService.java`
- NOVO: `src\main\java\com\example\security\service\GameMapper.java`
- NOVO: `src\main\java\com\example\security\service\InventarioService.java`
- NOVO: `src\main\java\com\example\security\service\ItemService.java`
- NOVO: `src\main\java\com\example\security\service\JogadorService.java`
- NOVO: `src\main\java\com\example\security\service\MissaoService.java`
- NOVO: `src\main\java\com\example\security\service\PersonagemService.java`
- NOVO: `src\main\java\com\example\security\service\ProgressoService.java`
- NOVO: `src\main\java\com\example\security\validation\Paginacao.java`
- NOVO: `src\main\java\com\example\security\validation\RegrasJogo.java`
- ALTERADO: `src\main\resources\application.properties`
- NOVO: `src\main\resources\db\migration\V11__relacionamentos_jogo.sql`
- NOVO: `src\test\java\com\example\security\GameApiIntegrationTests.java`
- NOVO: `src\test\java\com\example\security\LegacyMigrationTests.java`
- ALTERADO: `src\test\java\com\example\security\SecurityApplicationTests.java`
- NOVO: `src\test\resources\application-test.properties`
