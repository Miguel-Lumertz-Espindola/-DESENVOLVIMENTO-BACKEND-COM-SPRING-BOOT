# Interface do GuildaQuest

## Execução e edição no IntelliJ

A interface está integrada ao projeto Maven existente. Execute a classe `SecurityApplication` com Java 21 e acesse `http://localhost:8080/`. A configuração local do banco e do JWT continua sendo a mesma usada no backend.

Arquivos em `src/main/resources/static`:

| Arquivo | Responsabilidade |
| --- | --- |
| `index.html` | Estrutura de login, navegação e janelas acessíveis |
| `assets/app.css` | Estilo e adaptação para computador e celular |
| `assets/app.js` | Telas, formulários, operações e navegação por fragmentos `#` |
| `assets/api.js` | Requisições, envio do JWT e tratamento de respostas |
| `favicon.svg` | Identidade visual vetorial local |

Não há dependências externas de frontend, fontes remotas ou etapa de build JavaScript. O Maven inclui os arquivos estáticos no JAR. A página inicial e os recursos visuais são públicos somente para GET; as rotas de dados continuam protegidas. Não é necessário alterar o banco para instalar as telas.

## Telas e permissões

| Tela | Jogador | Administrador |
| --- | --- | --- |
| Entrar / Criar conta | Cadastro e login | Login na conta previamente autorizada |
| Visão geral | Quantidades reais e personagens próprios | Quantidades reais e personagens da guilda |
| Jogadores | CRUD do próprio perfil | Consultar, editar/excluir todos; criar o próprio perfil |
| Personagens | CRUD dos próprios personagens | Consultar, editar/excluir todos; criar no próprio perfil |
| Itens, Missões e Conquistas | Consulta dos catálogos | Cinco operações de CRUD por catálogo |
| Inventário | Selecionar personagem próprio, alterar capacidade, adicionar/alterar/remover itens | Mesmas ações para os personagens da guilda |
| Minha jornada | Iniciar/concluir missões próprias, acompanhar nível e XP | Mesmas ações para os personagens da guilda |
| Conquistas recebidas | Consultar as próprias | Consultar, conceder e revogar por jogador |

O cadastro público sempre cria um JOGADOR. A interface não promove contas nem altera permissões. Prepare um administrador pelas instruções do README. A lista da API é paginada em dez registros; a busca visual filtra somente a página atual. As seleções de personagens e catálogos percorrem todas as páginas da API.

## Regras apresentadas ao usuário

- A conta possui no máximo um perfil. O perfil é necessário antes de criar personagens.
- O personagem inicia com nível 1, experiência 0 e inventário de 20 espaços.
- Cada item distinto ocupa um espaço; unidades do mesmo item compartilham esse espaço.
- Capacidade de 1 a 500; quantidade de 1 a 1.000.000 por item.
- Ao iniciar uma missão, a recompensa é fixada. Concluí-la entrega XP uma única vez.
- A cada 100 XP, o personagem recebe um nível.
- Um jogador recebe cada conquista somente uma vez. A administração pode revogá-la.
- Exclusões e conclusões de missão pedem confirmação na tela. Erros retornados pelo backend são exibidos sem perder o formulário.
- Os botões de administração seguem o perfil atual, e a API verifica as permissões independentemente da interface.

## Roteiro de demonstração

Use contas exclusivas de demonstração, um administrador e um jogador, conforme o README.

1. Como administrador, cadastre um item, uma missão com 150 XP e uma conquista.
2. Saia e faça cadastro/login com o jogador.
3. Crie o perfil e um personagem; mostre também consulta, edição e listagem.
4. No inventário, adicione o item, altere sua quantidade e a capacidade.
5. Em Minha jornada, inicie e conclua a missão. Mostre nível 2 e 150 XP.
6. Como administrador, conceda a conquista ao jogador.
7. Como jogador, confira Conquistas recebidas. Mostre que o catálogo é somente de consulta para este perfil.
8. Para demonstrar exclusões sem afetar o fluxo principal, crie registros temporários sem vínculos e exclua-os. A exclusão de jogador/personagem elimina suas dependências; a conta de acesso é preservada.

Os dados da interface são obtidos da API. Não há registros fictícios embutidos nem senhas salvas pelo frontend. O botão Sair remove o token da aba. A expiração do token retorna ao login na próxima chamada autenticada.
