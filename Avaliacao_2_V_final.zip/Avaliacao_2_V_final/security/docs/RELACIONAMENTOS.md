# Relações e decisões do domínio

```mermaid
erDiagram
    USERS ||--o| JOGADORES : possui
    JOGADORES ||--o{ PERSONAGENS : controla
    PERSONAGENS ||--|| INVENTARIOS : possui
    INVENTARIOS ||--o{ ITENS_INVENTARIO : armazena
    ITENS ||--o{ ITENS_INVENTARIO : compoe
    PERSONAGENS ||--o{ PERSONAGENS_MISSOES : participa
    MISSOES ||--o{ PERSONAGENS_MISSOES : define
    JOGADORES ||--o{ JOGADORES_CONQUISTAS : recebe
    CONQUISTAS ||--o{ JOGADORES_CONQUISTAS : reconhece
```

As entidades de associação possuem ID próprio, duas FKs e unicidade do par. `ItemInventario` guarda quantidade; `PersonagemMissao`, estado, datas e recompensa fixada; `JogadorConquista`, a data de obtenção.

Cada personagem recebe inventário na mesma transação de criação. O acesso a entidades privadas é conferido no Service pela conta autenticada. Catálogos compartilhados só podem ser modificados por ADMIN. As listagens privadas filtram o proprietário no banco.

O banco remove dependências pertencentes ao agregado com ON DELETE CASCADE. FKs de catálogo usam RESTRICT. A API transforma a tentativa de excluir catálogo vinculado em 409.

Esta representação descreve o modelo implementado e pode servir de base ao DER acadêmico. Para a entrega, acrescentar atributos, tipos, PKs/FKs e o diagrama de classes UML no formato pedido pelo professor.
