# GuildaQuest

API REST para gerenciar jogadores, personagens, itens, inventários, missões e conquistas. O nome GuildaQuest é provisório e pode ser substituído pelo nome escolhido pela equipe.

## Tecnologias e organização

Java 21, Spring Boot 4.1.1, Spring Data JPA, Spring Security, JWT Auth0, PostgreSQL, Flyway, Bean Validation, Lombok e Swagger/OpenAPI.

```text
src/main/java/com/example/security/
  config/         JWT, autenticação, autorização e OpenAPI
  controller/     rotas HTTP
  service/        regras de negócio e transações
  repository/     consultas e persistência
  entity/         entidades JPA e associações
  dto/request/    contratos de entrada e validação de campos
  dto/response/   respostas sem entidades JPA e sem senhas
  validation/     regras compartilhadas e limites
  exception/      erros e tratamento centralizado
  doc/            interfaces de documentação da autenticação e teste
src/main/resources/db/migration/
src/test/         testes com PostgreSQL isolado
scripts/          execução dos testes em cluster temporário
docs/             relacionamentos e descrição das alterações
```

## Executar no IntelliJ

1. Abra a pasta que contém `pom.xml` como projeto Maven.
2. Configure Project SDK e a execução para Java 21 e recarregue o Maven.
3. Disponibilize um banco PostgreSQL (versões 12 a 17 atendem ao enunciado; os testes desta implementação usam 17).
4. Configure `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` e `JWT_SECRET` nas variáveis de ambiente da execução. A chave JWT deve ter pelo menos 32 bytes. Exemplo de URL: `jdbc:postgresql://localhost:5432/security`.
5. Execute `SecurityApplication.main()`.
6. Abra http://localhost:8080/swagger-ui.html. A definição JSON fica em http://localhost:8080/v3/api-docs.

Uma instalação feita sobre a cópia local pode incluir `application-local.properties` na raiz do projeto, com a configuração existente do usuário. Esse arquivo fica fora de `src`, é ignorado pelo Git e pelo pacote distribuível, e é lido com a execução iniciada na raiz do projeto. O perfil padrão é `local`; o projeto também funciona apenas com as variáveis de ambiente acima. A senha e o segredo não possuem valores fixos no código compartilhado.

## Executar pelo PowerShell

Defina as variáveis no terminal e use o wrapper restaurado:

```powershell
$env:JAVA_HOME = 'CAMINHO_DO_SEU_JDK_21'
$env:DB_URL = 'jdbc:postgresql://localhost:5432/security'
$env:DB_USERNAME = 'postgres'
$env:DB_PASSWORD = 'SUA_SENHA_LOCAL'
$env:JWT_SECRET = 'SUA_CHAVE_ALEATORIA_COM_PELO_MENOS_32_BYTES'
.\mvnw.cmd -DskipTests package
java -jar target\security-0.0.1-SNAPSHOT.jar
```

Para gerar uma chave no PowerShell:

```powershell
$jwtBytes = New-Object byte[] 48
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($jwtBytes)
$env:JWT_SECRET = [Convert]::ToBase64String($jwtBytes)
```

## Banco e atualização do projeto anterior

V1 a V10 permanecem sem alterações para preservar os checksums do Flyway. V11:

- Mantém as contas e os hashes da tabela `users`, normaliza o e-mail, cria unicidade e acrescenta `role`, inicialmente `JOGADOR`.
- Preserva as nove tabelas antigas do jogo com sufixo `_legado`.
- Cria as tabelas corrigidas, com nomes no plural, FKs, campos obrigatórios, verificações e unicidade dos vínculos.

Os registros legados não são importados automaticamente para as tabelas novas: as tabelas anteriores não continham IDs dos relacionamentos e não permitem descobrir seus proprietários com segurança. Se houver dados de jogo a reaproveitar, defina o mapeamento e faça uma nova migration de importação. Nenhuma conta existente é promovida automaticamente para administrador.

Caso existam contas com o mesmo e-mail desconsiderando maiúsculas/minúsculas/espaços, a criação da unicidade falha e a transação da V11 é revertida. Resolva essas duplicidades antes da atualização; a migration não escolhe nem exclui uma conta arbitrariamente.

As novas tabelas são `jogadores`, `personagens`, `inventarios`, `itens`, `itens_inventario`, `missoes`, `personagens_missoes`, `conquistas` e `jogadores_conquistas`. O Hibernate usa `ddl-auto=validate`; a criação do esquema é responsabilidade das migrations.

## Autenticação, primeiro administrador e dados de demonstração

Não existe senha de demonstração habilitada automaticamente. Crie contas exclusivas para a apresentação por `POST /auth/register`:

```json
{ "name": "Administrador Demo", "email": "admin@example.com", "password": "SenhaDemo123!" }
```

O cadastro público cria somente `JOGADOR`, mesmo que o cliente envie um campo `role`. Para preparar um administrador, o responsável pelo banco executa uma vez:

```sql
UPDATE users SET role = 'ADMIN' WHERE lower(email) = 'admin@example.com';
```

Faça login:

```http
POST /auth/login
Content-Type: application/json

{ "email": "admin@example.com", "password": "SenhaDemo123!" }
```

Resposta: `{ "token": "..." }`. Nas requisições, envie `Authorization: Bearer TOKEN`. No botão Authorize do Swagger, cole somente o token. A duração padrão é de uma hora. `GET /auth/me` informa ID, nome, e-mail e perfil da conta autenticada.

`ADMIN` administra os catálogos de itens, missões e conquistas e pode acessar os dados dos jogadores. `JOGADOR` lê os catálogos e cria/consulta/altera/exclui somente seu perfil e seus personagens; usa apenas seus inventários e progresso. A concessão e a revogação de conquistas são administrativas.

## Cinco CRUDs

Cada recurso abaixo possui POST e GET na coleção, além de GET, PUT e DELETE em `/{id}`:

| Recurso | Corpo para POST/PUT | Permissões de escrita |
| --- | --- | --- |
| `/jogadores` | `{"nome":"Miguel"}` | Próprio perfil; ADMIN pode atualizar/excluir os demais |
| `/personagens` | `{"nome":"Artemis","classe":"Mago"}` | Próprio personagem; ADMIN pode administrar os demais |
| `/itens` | `{"nome":"Espada","descricao":"Espada inicial","tipo":"ARMA","valor":25.50}` | ADMIN |
| `/missoes` | `{"nome":"Explorar a floresta","descricao":"Concluir a exploração","recompensaXp":150}` | ADMIN |
| `/conquistas` | `{"nome":"Explorador","descricao":"Reconhecimento pela exploração"}` | ADMIN |

A criação de perfil é vinculada à conta autenticada, no máximo um por conta. Crie o perfil antes do personagem. Um personagem nasce no nível 1, com experiência 0 e inventário de 20 espaços. Propriedade, nível e experiência não são aceitos como campos alteráveis pelo cliente.

As listagens usam `?page=0&size=20`, com limite de 100 e ordenação por ID. A resposta tem formato estável:

```json
{
  "conteudo": [{"id":1,"userId":2,"nome":"Miguel"}],
  "pagina":0,
  "tamanho":20,
  "totalElementos":1,
  "totalPaginas":1
}
```

Jogador comum recebe somente seus registros nas listagens privadas. Respostas de criação: 201 e cabeçalho Location. Atualizações e leituras: 200. Exclusões: 204.

## Inventário

- `GET /personagens/{id}/inventario`: consulta capacidade e itens.
- `PUT /personagens/{id}/inventario` com `{"capacidade":30}`: altera a capacidade entre 1 e 500; não permite diminuir abaixo dos itens distintos já armazenados.
- `POST /personagens/{id}/inventario/itens` com `{"itemId":1,"quantidade":2}`: adiciona ou soma quantidade; retorna 200 com o inventário atualizado.
- `PUT /personagens/{id}/inventario/itens/{itemId}` com `{"quantidade":5}`: define uma quantidade positiva.
- `DELETE /personagens/{id}/inventario/itens/{itemId}`: remove o vínculo do item com o inventário.

Capacidade é medida por itens distintos. Cada item pode ter entre 1 e 1.000.000 unidades. Adições e alterações bloqueiam a linha do personagem durante a transação para evitar ultrapassar a capacidade em requisições simultâneas.

## Missões e conquistas

- `GET /personagens/{id}/missoes`: lista os vínculos e seus estados.
- `POST /personagens/{id}/missoes/{missaoId}`: inicia uma missão; retorna 201. A recompensa é registrada nesse momento.
- `PATCH /personagens/{id}/missoes/{missaoId}/concluir`: conclui, registra a data e acrescenta XP uma única vez. Repetição retorna 409.
- `GET /jogadores/{id}/conquistas`: lista conquistas recebidas.
- `POST /jogadores/{id}/conquistas/{conquistaId}`: ADMIN concede uma conquista; retorna 201. Duplicidade retorna 409.
- `DELETE /jogadores/{id}/conquistas/{conquistaId}`: ADMIN revoga a conquista; retorna 204.

Cada 100 pontos de experiência incrementam um nível (`nivel = 1 + experiencia / 100`). A conclusão e o crédito de XP são transacionais e protegidos por bloqueio pessimista do personagem, inclusive contra duas chamadas concorrentes. Alterar o catálogo de missão não modifica a recompensa de uma missão já iniciada.

A exclusão de jogador/personagem remove suas dependências do jogo por cascata no banco. Contas de autenticação e catálogos compartilhados são preservados. Um item, missão ou conquista ainda vinculado a dados de jogo retorna 409 ao tentar excluir.

## Validações e erros

DTOs verificam textos obrigatórios, tamanho, e-mail, IDs positivos, valores não negativos e quantidades. A senha de cadastro possui mínimo de oito caracteres e limite de 72 bytes UTF-8 para BCrypt.

```json
{
  "timestamp":"2026-11-02T12:00:00Z",
  "status":400,
  "message":"Dados inválidos",
  "path":"/jogadores",
  "fieldErrors":{"nome":"não deve estar em branco"}
}
```

400: entrada inválida; 401: credenciais/token inválidos, expirados ou ausentes; 403: falta de permissão; 404: recurso inexistente; 409: duplicidade, capacidade, vínculo ou conflito de negócio. Senhas, entidades JPA e mensagens SQL não integram as respostas.

## Executar os testes

Os testes usam PostgreSQL real e um banco separado cujo nome termina em `_tests`. O perfil `test` substitui credenciais e segredo da aplicação. Não aponte testes para seu banco de uso.

No Windows com PostgreSQL instalado:

```powershell
.\scripts\test.ps1 -PgBin 'C:\Program Files\PostgreSQL\17\bin'
```

O script cria um cluster temporário dentro de `target`, escolhe uma porta local disponível, executa os testes e encerra esse cluster. Não usa o serviço PostgreSQL instalado nem altera o banco de desenvolvimento.

Para usar um banco de testes separado que você já preparou:

```powershell
$env:TEST_DB_URL = 'jdbc:postgresql://localhost:55439/security_tests'
$env:TEST_DB_USERNAME = 'security_test'
$env:TEST_DB_PASSWORD = 'SENHA_DO_BANCO_DE_TESTES'
.\mvnw.cmd test
```

Os testes cobrem cinco CRUDs, autenticação, autorização por perfil/proprietário, validações, FKs, cascatas, inventário, recompensas, concorrência, Swagger e atualização das migrations com preservação de registros antigos.

## Itens acadêmicos a completar pela equipe

Registrar integrantes e responsabilidades, finalizar documento de análise, conferir DER/UML, preparar protótipos/frontend conforme a orientação do professor, assegurar contribuições no GitHub e preparar a apresentação. O desenvolvimento do backend não substitui essas entregas.
